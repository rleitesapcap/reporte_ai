-- ============================================================================
-- REPORTE AI - Schema Completo PostgreSQL + PostGIS
-- Versão: 1.0.0
-- Descrição: Plataforma de Community Intelligence as a Service (CIaaS)
-- ============================================================================

-- Extensões necessárias
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;     -- similaridade textual para dedup
CREATE EXTENSION IF NOT EXISTS unaccent;    -- normalização de acentos pt-BR

-- ============================================================================
-- ENUMS
-- ============================================================================

CREATE TYPE status_ocorrencia AS ENUM (
    'RECEBIDA',
    'EM_ANALISE',
    'VALIDADA',
    'EM_RESOLUCAO',
    'RESOLVIDA',
    'ARQUIVADA',
    'REJEITADA'
);

CREATE TYPE gravidade_ocorrencia AS ENUM (
    'BAIXA',
    'MEDIA',
    'ALTA',
    'CRITICA'
);

CREATE TYPE canal_entrada AS ENUM (
    'WHATSAPP_GUIADO',
    'WHATSAPP_RAPIDO',
    'WEB',
    'API'
);

CREATE TYPE modo_interacao AS ENUM (
    'GUIADO',
    'RAPIDO',
    'VOZ'
);

-- ============================================================================
-- TABELAS DE REFERÊNCIA
-- ============================================================================

CREATE TABLE cidades (
    id              BIGSERIAL PRIMARY KEY,
    nome            VARCHAR(200) NOT NULL,
    uf              CHAR(2) NOT NULL,
    ibge_codigo     VARCHAR(7) UNIQUE,
    populacao       INTEGER,
    area_km2        NUMERIC(10,2),
    turistica       BOOLEAN DEFAULT FALSE,
    ativa           BOOLEAN DEFAULT FALSE,
    plano           VARCHAR(50) DEFAULT 'COMUNIDADE',  -- COMUNIDADE, MUNICIPAL, ENTERPRISE
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE bairros (
    id              BIGSERIAL PRIMARY KEY,
    cidade_id       BIGINT NOT NULL REFERENCES cidades(id),
    nome            VARCHAR(200) NOT NULL,
    geom            GEOMETRY(POLYGON, 4326),  -- perímetro do bairro
    populacao_est   INTEGER,
    area_km2        NUMERIC(8,4),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(cidade_id, nome)
);

CREATE TABLE categorias (
    id              BIGSERIAL PRIMARY KEY,
    codigo          VARCHAR(50) UNIQUE NOT NULL,
    nome            VARCHAR(200) NOT NULL,
    descricao       TEXT,
    icone           VARCHAR(50),
    cor             VARCHAR(7),       -- hex color para dashboard
    peso_prioridade NUMERIC(3,1) DEFAULT 1.0,
    ativa           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE subcategorias (
    id              BIGSERIAL PRIMARY KEY,
    categoria_id    BIGINT NOT NULL REFERENCES categorias(id),
    codigo          VARCHAR(50) UNIQUE NOT NULL,
    nome            VARCHAR(200) NOT NULL,
    descricao       TEXT,
    keywords        TEXT[],           -- palavras-chave para classificação
    ativa           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================================
-- USUÁRIOS (hash-based, LGPD compliant)
-- ============================================================================

CREATE TABLE usuarios (
    id              BIGSERIAL PRIMARY KEY,
    hash_telefone   VARCHAR(64) UNIQUE NOT NULL,  -- SHA-256 do telefone
    cidade_id       BIGINT REFERENCES cidades(id),
    primeiro_uso    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ultimo_uso      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    total_reportes  INTEGER DEFAULT 0,
    score_confianca NUMERIC(5,2) DEFAULT 50.0,    -- 0-100, cresce com uso
    badges          JSONB DEFAULT '[]'::JSONB,
    modo_preferido  modo_interacao DEFAULT 'GUIADO',
    opt_in_notif    BOOLEAN DEFAULT TRUE,
    ativo           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================================
-- TABELA PRINCIPAL: OCORRÊNCIAS
-- ============================================================================

CREATE TABLE ocorrencias (
    id                  BIGSERIAL PRIMARY KEY,
    protocolo           VARCHAR(20) UNIQUE NOT NULL,   -- RPT-2026-XXXXX
    cidade_id           BIGINT NOT NULL REFERENCES cidades(id),
    usuario_id          BIGINT REFERENCES usuarios(id),
    
    -- Classificação
    categoria_id        BIGINT REFERENCES categorias(id),
    subcategoria_id     BIGINT REFERENCES subcategorias(id),
    descricao           TEXT NOT NULL,
    descricao_norm      TEXT,          -- normalizada (lowercase, unaccent) para busca
    
    -- Geolocalização
    latitude            NUMERIC(10,7),
    longitude           NUMERIC(10,7),
    geom                GEOMETRY(POINT, 4326),  -- ponto geoespacial
    bairro_id           BIGINT REFERENCES bairros(id),
    endereco_texto      VARCHAR(500),           -- endereço livre digitado
    geocodificado       BOOLEAN DEFAULT FALSE,
    
    -- Avaliação
    gravidade           gravidade_ocorrencia DEFAULT 'MEDIA',
    frequencia          INTEGER DEFAULT 1,       -- quantas vezes já aconteceu (percepção)
    reincidencia        INTEGER DEFAULT 0,       -- incrementado por dedup
    score_prioridade    NUMERIC(8,2) DEFAULT 0,
    score_confianca     NUMERIC(5,2) DEFAULT 50.0,
    score_sentimento    NUMERIC(5,2) DEFAULT 0,  -- -1 a 1 (urgência percebida)
    
    -- Mídia
    foto_url            VARCHAR(500),
    foto_validada       BOOLEAN DEFAULT FALSE,
    audio_url           VARCHAR(500),
    
    -- Metadata
    canal               canal_entrada NOT NULL,
    status              status_ocorrencia DEFAULT 'RECEBIDA',
    cluster_id          BIGINT,        -- FK para vinculos se for parte de cluster
    classificado_por_ia BOOLEAN DEFAULT FALSE,
    confianca_class_ia  NUMERIC(5,2),  -- 0-100 confiança da classificação automática
    
    -- Timestamps
    data_registro       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    data_validacao      TIMESTAMP WITH TIME ZONE,
    data_resolucao      TIMESTAMP WITH TIME ZONE,
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Trigger para gerar geom a partir de lat/lng
CREATE OR REPLACE FUNCTION fn_set_geom()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.latitude IS NOT NULL AND NEW.longitude IS NOT NULL THEN
        NEW.geom := ST_SetSRID(ST_MakePoint(NEW.longitude, NEW.latitude), 4326);
    END IF;
    -- Normalizar descrição
    NEW.descricao_norm := lower(unaccent(NEW.descricao));
    -- Atualizar updated_at
    NEW.updated_at := NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ocorrencia_before
    BEFORE INSERT OR UPDATE ON ocorrencias
    FOR EACH ROW EXECUTE FUNCTION fn_set_geom();

-- ============================================================================
-- VÍNCULOS (deduplicação / clusters)
-- ============================================================================

CREATE TABLE vinculos_ocorrencias (
    id                  BIGSERIAL PRIMARY KEY,
    ocorrencia_pai_id   BIGINT NOT NULL REFERENCES ocorrencias(id),
    ocorrencia_filha_id BIGINT NOT NULL REFERENCES ocorrencias(id),
    tipo_vinculo        VARCHAR(50) DEFAULT 'DUPLICATA',  -- DUPLICATA, SIMILAR, RELACIONADA
    similaridade_texto  NUMERIC(5,4),   -- 0-1
    distancia_metros    NUMERIC(10,2),
    criado_por          VARCHAR(20) DEFAULT 'IA',  -- IA ou MANUAL
    created_at          TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(ocorrencia_pai_id, ocorrencia_filha_id)
);

-- ============================================================================
-- HISTÓRICO DE STATUS
-- ============================================================================

CREATE TABLE historico_status (
    id              BIGSERIAL PRIMARY KEY,
    ocorrencia_id   BIGINT NOT NULL REFERENCES ocorrencias(id),
    status_anterior status_ocorrencia,
    status_novo     status_ocorrencia NOT NULL,
    responsavel     VARCHAR(200),
    observacao      TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================================
-- CONVERSAS WHATSAPP (estado da máquina de estados)
-- ============================================================================

CREATE TABLE conversas_whatsapp (
    id              BIGSERIAL PRIMARY KEY,
    usuario_id      BIGINT NOT NULL REFERENCES usuarios(id),
    cidade_id       BIGINT NOT NULL REFERENCES cidades(id),
    estado_atual    VARCHAR(50) NOT NULL DEFAULT 'INICIO',
    dados_parciais  JSONB DEFAULT '{}'::JSONB,  -- dados coletados até o momento
    ocorrencia_id   BIGINT REFERENCES ocorrencias(id),  -- vincula quando finalizado
    modo            modo_interacao DEFAULT 'GUIADO',
    expirada        BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================================
-- NOTIFICAÇÕES
-- ============================================================================

CREATE TABLE notificacoes (
    id              BIGSERIAL PRIMARY KEY,
    usuario_id      BIGINT NOT NULL REFERENCES usuarios(id),
    ocorrencia_id   BIGINT REFERENCES ocorrencias(id),
    tipo            VARCHAR(50) NOT NULL,  -- STATUS_UPDATE, IMPACTO_MENSAL, BADGE, RESOLUCAO
    mensagem        TEXT NOT NULL,
    enviada         BOOLEAN DEFAULT FALSE,
    enviada_em      TIMESTAMP WITH TIME ZONE,
    canal           VARCHAR(20) DEFAULT 'WHATSAPP',
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================================
-- SEQUÊNCIA PARA PROTOCOLO
-- ============================================================================

CREATE SEQUENCE seq_protocolo START WITH 1 INCREMENT BY 1;

-- ============================================================================
-- ÍNDICES
-- ============================================================================

-- Geoespacial
CREATE INDEX idx_ocorrencias_geom ON ocorrencias USING GIST(geom);
CREATE INDEX idx_bairros_geom ON bairros USING GIST(geom);

-- Busca textual
CREATE INDEX idx_ocorrencias_descricao_trgm ON ocorrencias USING GIN(descricao_norm gin_trgm_ops);

-- Queries frequentes
CREATE INDEX idx_ocorrencias_cidade_status ON ocorrencias(cidade_id, status);
CREATE INDEX idx_ocorrencias_cidade_categoria ON ocorrencias(cidade_id, categoria_id);
CREATE INDEX idx_ocorrencias_protocolo ON ocorrencias(protocolo);
CREATE INDEX idx_ocorrencias_data_registro ON ocorrencias(data_registro DESC);
CREATE INDEX idx_ocorrencias_score ON ocorrencias(score_prioridade DESC);
CREATE INDEX idx_ocorrencias_cluster ON ocorrencias(cluster_id) WHERE cluster_id IS NOT NULL;
CREATE INDEX idx_historico_ocorrencia ON historico_status(ocorrencia_id, created_at DESC);
CREATE INDEX idx_conversas_usuario ON conversas_whatsapp(usuario_id, expirada) WHERE NOT expirada;
CREATE INDEX idx_notificacoes_pendentes ON notificacoes(usuario_id, enviada) WHERE NOT enviada;
CREATE INDEX idx_usuarios_hash ON usuarios(hash_telefone);

-- ============================================================================
-- MATERIALIZED VIEWS (métricas agregadas para dashboard)
-- ============================================================================

CREATE MATERIALIZED VIEW mv_metricas_cidade AS
SELECT
    c.id AS cidade_id,
    c.nome AS cidade_nome,
    COUNT(o.id) AS total_ocorrencias,
    COUNT(o.id) FILTER (WHERE o.status = 'RESOLVIDA') AS total_resolvidas,
    COUNT(o.id) FILTER (WHERE o.status NOT IN ('RESOLVIDA', 'ARQUIVADA', 'REJEITADA')) AS total_abertas,
    ROUND(AVG(o.score_prioridade), 2) AS score_medio,
    COUNT(DISTINCT o.usuario_id) AS usuarios_unicos,
    COUNT(DISTINCT o.bairro_id) AS bairros_cobertos,
    ROUND(
        100.0 * COUNT(o.id) FILTER (WHERE o.status = 'RESOLVIDA') / NULLIF(COUNT(o.id), 0), 1
    ) AS taxa_resolucao_pct,
    ROUND(
        AVG(EXTRACT(EPOCH FROM (o.data_resolucao - o.data_registro)) / 86400)
        FILTER (WHERE o.data_resolucao IS NOT NULL), 1
    ) AS tempo_medio_resolucao_dias,
    MAX(o.data_registro) AS ultimo_reporte
FROM cidades c
LEFT JOIN ocorrencias o ON o.cidade_id = c.id
WHERE c.ativa = TRUE
GROUP BY c.id, c.nome
WITH NO DATA;

CREATE UNIQUE INDEX idx_mv_metricas_cidade ON mv_metricas_cidade(cidade_id);

CREATE MATERIALIZED VIEW mv_ranking_categorias AS
SELECT
    o.cidade_id,
    cat.id AS categoria_id,
    cat.nome AS categoria_nome,
    cat.cor,
    COUNT(o.id) AS total,
    ROUND(AVG(o.score_prioridade), 2) AS score_medio,
    COUNT(o.id) FILTER (WHERE o.data_registro >= NOW() - INTERVAL '7 days') AS ultimos_7_dias,
    COUNT(o.id) FILTER (WHERE o.data_registro >= NOW() - INTERVAL '30 days') AS ultimos_30_dias
FROM ocorrencias o
JOIN categorias cat ON cat.id = o.categoria_id
GROUP BY o.cidade_id, cat.id, cat.nome, cat.cor
WITH NO DATA;

CREATE UNIQUE INDEX idx_mv_ranking_cat ON mv_ranking_categorias(cidade_id, categoria_id);

CREATE MATERIALIZED VIEW mv_heatmap_data AS
SELECT
    o.cidade_id,
    o.latitude,
    o.longitude,
    o.categoria_id,
    o.score_prioridade,
    o.status,
    o.data_registro
FROM ocorrencias o
WHERE o.latitude IS NOT NULL
  AND o.longitude IS NOT NULL
  AND o.data_registro >= NOW() - INTERVAL '90 days'
WITH NO DATA;

-- ============================================================================
-- FUNÇÃO: Refresh das materialized views (chamar via cron/scheduler)
-- ============================================================================

CREATE OR REPLACE FUNCTION fn_refresh_materialized_views()
RETURNS VOID AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_metricas_cidade;
    REFRESH MATERIALIZED VIEW CONCURRENTLY mv_ranking_categorias;
    REFRESH MATERIALIZED VIEW mv_heatmap_data;
END;
$$ LANGUAGE plpgsql;

-- ============================================================================
-- DADOS INICIAIS: Categorias e Subcategorias
-- ============================================================================

INSERT INTO categorias (codigo, nome, descricao, icone, cor, peso_prioridade) VALUES
    ('LIXO',           'Lixo e Resíduos',           'Acúmulo de lixo, descarte irregular, coleta atrasada',               'trash',       '#e74c3c', 1.2),
    ('ILUMINACAO',     'Iluminação Pública',         'Postes apagados, lâmpadas queimadas, áreas escuras',                 'lightbulb',   '#f39c12', 1.3),
    ('BURACO',         'Buracos e Pavimentação',     'Buracos em vias, calçadas danificadas, asfalto deteriorado',         'road',        '#95a5a6', 1.4),
    ('AGUA',           'Água e Esgoto',              'Vazamentos, esgoto a céu aberto, falta d''água',                     'droplet',     '#3498db', 1.5),
    ('VEGETACAO',      'Vegetação e Áreas Verdes',   'Mato alto, árvores caídas, praças abandonadas',                      'tree',        '#27ae60', 1.0),
    ('TRANSITO',       'Trânsito e Sinalização',     'Semáforos quebrados, falta de sinalização, problemas de trânsito',    'traffic',     '#e67e22', 1.3),
    ('SEGURANCA',      'Segurança Pública',          'Áreas inseguras, falta de policiamento, vandalismo',                 'shield',      '#c0392b', 1.5),
    ('ANIMAIS',        'Animais',                    'Animais abandonados, infestação, animais perigosos',                 'paw',         '#8e44ad', 1.1),
    ('POLUICAO',       'Poluição',                   'Poluição sonora, do ar, visual, queimadas',                          'wind',        '#7f8c8d', 1.2),
    ('ACESSIBILIDADE', 'Acessibilidade',             'Falta de rampa, calçada obstruída, dificuldade de acesso',           'wheelchair',  '#2980b9', 1.1),
    ('TURISMO',        'Infraestrutura Turística',   'Problemas em pontos turísticos, sinalização turística, receptivo',   'camera',      '#1abc9c', 1.0),
    ('OUTROS',         'Outros',                     'Problemas que não se enquadram nas categorias acima',                'help-circle', '#bdc3c7', 0.8);

INSERT INTO subcategorias (categoria_id, codigo, nome, keywords) VALUES
    (1, 'LIXO_ACUMULADO',     'Lixo acumulado',           ARRAY['lixo','lixão','entulho','acumulado','sujeira']),
    (1, 'COLETA_ATRASADA',    'Coleta atrasada',          ARRAY['coleta','lixeiro','caminhão','atrasado','não passou']),
    (1, 'DESCARTE_IRREGULAR', 'Descarte irregular',       ARRAY['descarte','jogaram','irregular','terreno','baldio']),
    (2, 'POSTE_APAGADO',      'Poste apagado',            ARRAY['poste','apagado','luz','escuro','lâmpada']),
    (2, 'FIACAO_EXPOSTA',     'Fiação exposta',           ARRAY['fio','fiação','exposto','perigo','elétrico']),
    (3, 'BURACO_VIA',         'Buraco em via',            ARRAY['buraco','cratera','asfalto','pista','via']),
    (3, 'CALCADA_DANIFICADA', 'Calçada danificada',       ARRAY['calçada','passeio','quebrada','irregular']),
    (4, 'VAZAMENTO',          'Vazamento de água',        ARRAY['vazamento','água','vazando','cano','tubulação']),
    (4, 'ESGOTO',             'Esgoto a céu aberto',      ARRAY['esgoto','fedor','mau cheiro','aberto']),
    (4, 'FALTA_AGUA',         'Falta d''água',            ARRAY['falta','água','sem água','abastecimento']),
    (5, 'MATO_ALTO',          'Mato alto',                ARRAY['mato','capim','alto','terreno','roçar']),
    (5, 'ARVORE_CAIDA',       'Árvore caída/risco',       ARRAY['árvore','caída','galho','risco','cair']),
    (6, 'SEMAFORO',           'Semáforo com defeito',     ARRAY['semáforo','sinal','quebrado','piscando']),
    (6, 'SINALIZACAO',        'Falta de sinalização',     ARRAY['placa','sinalização','faixa','pedestre']),
    (7, 'VANDALISMO',         'Vandalismo',               ARRAY['vandalismo','pichação','depredação','destruição']),
    (7, 'AREA_INSEGURA',      'Área insegura',            ARRAY['inseguro','perigoso','assalto','medo','escuro']),
    (8, 'ANIMAL_ABANDONADO',  'Animal abandonado',        ARRAY['cachorro','gato','abandonado','animal','rua']),
    (9, 'QUEIMADA',           'Queimada',                 ARRAY['queimada','fogo','incêndio','fumaça','queimando']),
    (9, 'POLUICAO_SONORA',    'Poluição sonora',          ARRAY['barulho','som','alto','música','perturbação']),
    (10,'CALCADA_OBSTRUIDA',  'Calçada obstruída',        ARRAY['obstruída','bloqueada','cadeirante','acessibilidade']),
    (11,'PONTO_TURISTICO',    'Problema em ponto turístico', ARRAY['turismo','turístico','ponto','visitação','mirante']),
    (12,'OUTRO_GENERICO',     'Outro problema',           ARRAY['outro','diferente','geral']);

-- Capitólio como cidade inicial
INSERT INTO cidades (nome, uf, ibge_codigo, populacao, turistica, ativa, plano)
VALUES ('Capitólio', 'MG', '3112802', 9023, TRUE, TRUE, 'COMUNIDADE');
