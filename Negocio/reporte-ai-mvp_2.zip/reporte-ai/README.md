# Reporte AI — MVP Backend

**Plataforma de Community Intelligence as a Service (CIaaS)**

Backend Spring Boot para coleta, classificação e priorização de ocorrências urbanas via WhatsApp, com análise geoespacial e dashboard de inteligência comunitária.

---

## Stack Tecnológico

| Camada | Tecnologia |
|---|---|
| Backend API | Java 21 + Spring Boot 3.3 |
| Banco de Dados | PostgreSQL 16 + PostGIS 3 |
| Migrations | Flyway |
| WhatsApp | Evolution API v2 |
| NLP/Classificação | OpenAI API (gpt-4o-mini) + fallback por keywords |
| Geoespacial | PostGIS + Hibernate Spatial |

---

## Pré-requisitos

- Java 21+
- Maven 3.9+
- PostgreSQL 16 com extensão PostGIS
- Evolution API rodando (para WhatsApp)
- Chave OpenAI (opcional — fallback por keywords funciona sem)

---

## Setup Rápido

### 1. Banco de dados

```bash
# Criar database
createdb reporteai

# Habilitar extensões (o Flyway faz isso, mas pode ser necessário superuser)
psql reporteai -c "CREATE EXTENSION IF NOT EXISTS postgis;"
psql reporteai -c "CREATE EXTENSION IF NOT EXISTS pg_trgm;"
psql reporteai -c "CREATE EXTENSION IF NOT EXISTS unaccent;"
```

### 2. Variáveis de ambiente

```bash
export DB_USERNAME=postgres
export DB_PASSWORD=postgres

# Evolution API (WhatsApp)
export EVOLUTION_API_URL=http://localhost:8080
export EVOLUTION_API_KEY=sua-api-key
export EVOLUTION_INSTANCE=reporteai

# OpenAI (opcional)
export OPENAI_API_KEY=sk-...

# Webhook
export WEBHOOK_TOKEN=seu-token-secreto
```

### 3. Build e execução

```bash
mvn clean package -DskipTests
java -jar target/reporte-ai-0.1.0-SNAPSHOT.jar
```

A aplicação sobe na porta **8081**.

---

## Arquitetura

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│   WhatsApp      │────▶│  Evolution API   │────▶│  Webhook        │
│   (Cidadão)     │◀────│  (Gateway)       │◀────│  Controller     │
└─────────────────┘     └──────────────────┘     └────────┬────────┘
                                                          │
                                                 ┌────────▼────────┐
                                                 │  MessageHandler │
                                                 │  (State Machine)│
                                                 └────────┬────────┘
                                                          │
                        ┌─────────────────────────────────┼──────────────────────────┐
                        │                                 │                          │
               ┌────────▼────────┐   ┌───────────▼──────────┐   ┌──────────▼───────┐
               │ Classificação   │   │  OcorrenciaService    │   │  Score Service   │
               │ (OpenAI/KW)     │   │  (Orquestrador)       │   │  (Priorização)   │
               └─────────────────┘   └───────────┬──────────┘   └──────────────────┘
                                                 │
                                     ┌───────────▼──────────┐
                                     │  Deduplicação        │
                                     │  (Jaccard + PostGIS) │
                                     └───────────┬──────────┘
                                                 │
                                     ┌───────────▼──────────┐
                                     │  PostgreSQL+PostGIS  │
                                     │  (Persistência)      │
                                     └──────────────────────┘
```

---

## API Endpoints

### Ocorrências

| Método | Endpoint | Descrição |
|---|---|---|
| `POST` | `/api/v1/ocorrencias` | Criar ocorrência |
| `GET` | `/api/v1/ocorrencias?cidadeId=1&page=0&size=20` | Listar por cidade |
| `GET` | `/api/v1/ocorrencias/protocolo/{RPT-2026-XXXXX}` | Buscar por protocolo |
| `GET` | `/api/v1/ocorrencias/abertas?cidadeId=1` | Listar abertas (por prioridade) |
| `GET` | `/api/v1/ocorrencias/top?cidadeId=1&limit=10` | Top N por prioridade |
| `PATCH` | `/api/v1/ocorrencias/{protocolo}/status` | Atualizar status |

### Dashboard

| Método | Endpoint | Descrição |
|---|---|---|
| `GET` | `/api/v1/dashboard?cidadeId=1` | Summary completo (métricas + ranking + heatmap) |
| `GET` | `/api/v1/dashboard/categorias` | Categorias ativas |

### Webhook

| Método | Endpoint | Descrição |
|---|---|---|
| `POST` | `/webhook/whatsapp` | Receber mensagens da Evolution API |
| `GET` | `/webhook/whatsapp` | Health check |

---

## Exemplos de Uso

### Criar ocorrência via API

```bash
curl -X POST http://localhost:8081/api/v1/ocorrencias \
  -H "Content-Type: application/json" \
  -d '{
    "descricao": "Buraco enorme na Rua das Flores, próximo ao posto de gasolina",
    "latitude": -20.6132,
    "longitude": -46.0492,
    "gravidade": "ALTA",
    "canal": "API",
    "cidadeId": 1
  }'
```

### Consultar protocolo

```bash
curl http://localhost:8081/api/v1/ocorrencias/protocolo/RPT-2026-00001
```

### Dashboard

```bash
curl http://localhost:8081/api/v1/dashboard?cidadeId=1
```

### Atualizar status

```bash
curl -X PATCH http://localhost:8081/api/v1/ocorrencias/RPT-2026-00001/status \
  -H "Content-Type: application/json" \
  -d '{
    "status": "EM_RESOLUCAO",
    "responsavel": "Secretaria de Obras",
    "observacao": "Equipe designada para reparo"
  }'
```

---

## Fluxo WhatsApp

### Modo Guiado (passo a passo)
1. Usuário manda mensagem → Bot envia menu
2. Escolhe "Reportar problema"
3. Seleciona categoria (1-12)
4. Descreve o problema
5. Envia localização (GPS ou texto)
6. Informa gravidade (1-4)
7. Envia foto (ou pula)
8. Confirma → Protocolo gerado

### Modo Rápido (1 mensagem)
1. Usuário envia **foto + localização + texto** em uma mensagem
2. IA classifica automaticamente
3. Protocolo gerado instantaneamente

### Consulta de Protocolo
- Envie `RPT-2026-XXXXX` a qualquer momento para ver o status

---

## Configuração da Evolution API

### 1. Configurar webhook na Evolution API

```bash
curl -X POST http://localhost:8080/webhook/set/reporteai \
  -H "apikey: SUA_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "url": "http://SEU_IP:8081/webhook/whatsapp",
    "webhook_by_events": true,
    "events": ["MESSAGES_UPSERT"]
  }'
```

### 2. Conectar instância WhatsApp

```bash
curl -X POST http://localhost:8080/instance/connect/reporteai \
  -H "apikey: SUA_API_KEY"
```

Escaneie o QR Code gerado com o WhatsApp.

---

## Pipeline de Processamento

```
Mensagem → Classificação (NLP) → Geocodificação → Deduplicação → Score → Persistência → Feedback
```

### Score de Prioridade

```
Score = (gravidade × 3.0) + (frequência × 2.0) + (densidade × 1.5)
      + (reincidência × 2.0) + (foto × 1.0) + (sentimento × 1.5)
```

### Deduplicação

- **Geográfica**: PostGIS `ST_DWithin` (raio 200m configurável)
- **Textual**: Jaccard similarity nos tokens normalizados (threshold 0.75)
- **Temporal**: Janela de 30 dias
- **Bonus**: +0.15 se mesma categoria

---

## Estrutura do Projeto

```
src/main/java/com/reporteai/
├── ReporteAiApplication.java
├── config/
│   ├── GlobalExceptionHandler.java
│   └── ScheduledTasks.java
├── controller/
│   ├── DashboardController.java
│   ├── OcorrenciaController.java
│   └── WebhookController.java
├── model/
│   ├── dto/
│   │   ├── DashboardSummary.java
│   │   ├── EvolutionWebhookPayload.java
│   │   ├── OcorrenciaRequest.java
│   │   └── OcorrenciaResponse.java
│   ├── entity/
│   │   ├── Bairro.java
│   │   ├── Categoria.java
│   │   ├── Cidade.java
│   │   ├── ConversaWhatsApp.java
│   │   ├── HistoricoStatus.java
│   │   ├── Ocorrencia.java
│   │   ├── Subcategoria.java
│   │   ├── Usuario.java
│   │   └── VinculoOcorrencia.java
│   └── enums/
│       ├── CanalEntrada.java
│       ├── EstadoConversa.java
│       ├── GravidadeOcorrencia.java
│       └── StatusOcorrencia.java
├── repository/
│   ├── CategoriaRepository.java
│   ├── CidadeRepository.java
│   ├── ConversaWhatsAppRepository.java
│   ├── HistoricoStatusRepository.java
│   ├── OcorrenciaRepository.java
│   ├── SubcategoriaRepository.java
│   ├── UsuarioRepository.java
│   └── VinculoOcorrenciaRepository.java
├── service/
│   ├── ClassificacaoService.java
│   ├── DeduplicacaoService.java
│   ├── OcorrenciaService.java
│   ├── ProtocoloService.java
│   ├── ScoreService.java
│   └── WhatsAppService.java
└── whatsapp/
    └── MessageHandler.java
```

---

## Próximos Passos (Fase 2)

- [ ] NLP avançado com embeddings (sentence-transformers)
- [ ] Análise de sentimento na descrição
- [ ] Speech-to-text para modo voz
- [ ] Portal administrativo (gestores)
- [ ] Relatórios PDF automatizados (ReportLab/JasperReports)
- [ ] Sistema de badges e gamificação
- [ ] API pública para dados anonimizados
- [ ] Integração com sistemas da prefeitura
- [ ] App mobile React Native

---

## Licença

Proprietário — Reporte AI © 2026
