package com.reporteai.model.entity;

import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Polygon;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "bairros", uniqueConstraints = @UniqueConstraint(columnNames = {"cidade_id", "nome"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Bairro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cidade_id", nullable = false)
    private Cidade cidade;

    @Column(nullable = false, length = 200)
    private String nome;

    @Column(columnDefinition = "geometry(Polygon,4326)")
    private Polygon geom;

    @Column(name = "populacao_est")
    private Integer populacaoEst;

    @Column(name = "area_km2")
    private BigDecimal areaKm2;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
    }
}
