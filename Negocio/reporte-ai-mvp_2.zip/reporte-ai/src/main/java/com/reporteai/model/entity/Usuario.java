package com.reporteai.model.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "usuarios")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "hash_telefone", unique = true, nullable = false, length = 64)
    private String hashTelefone;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cidade_id")
    private Cidade cidade;

    @Column(name = "primeiro_uso", updatable = false)
    private OffsetDateTime primeiroUso;

    @Column(name = "ultimo_uso")
    private OffsetDateTime ultimoUso;

    @Column(name = "total_reportes")
    @Builder.Default
    private Integer totalReportes = 0;

    @Column(name = "score_confianca")
    @Builder.Default
    private BigDecimal scoreConfianca = new BigDecimal("50.0");

    @Column(columnDefinition = "jsonb")
    @Builder.Default
    private String badges = "[]";

    @Column(name = "opt_in_notif")
    @Builder.Default
    private Boolean optInNotif = true;

    @Builder.Default
    private Boolean ativo = true;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
        updatedAt = OffsetDateTime.now();
        primeiroUso = OffsetDateTime.now();
        ultimoUso = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = OffsetDateTime.now();
        ultimoUso = OffsetDateTime.now();
    }

    public void incrementarReportes() {
        this.totalReportes++;
        // Score de confiança cresce com uso (máx 100)
        if (this.scoreConfianca.doubleValue() < 100) {
            this.scoreConfianca = this.scoreConfianca.add(new BigDecimal("2.0"))
                    .min(new BigDecimal("100.0"));
        }
    }
}
