package com.reporteai.model.dto;

import lombok.*;
import java.math.BigDecimal;
import java.util.List;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class DashboardSummary {

    private Long totalOcorrencias;
    private Long totalAbertas;
    private Long totalResolvidas;
    private BigDecimal taxaResolucao;
    private BigDecimal tempoMedioResolucaoDias;
    private Long usuariosUnicos;
    private Long bairrosCobertos;
    private List<CategoriaRanking> rankingCategorias;
    private List<HeatmapPoint> heatmapData;

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CategoriaRanking {
        private String categoriaNome;
        private String cor;
        private Long total;
        private BigDecimal scoreMedio;
        private Long ultimos7Dias;
        private Long ultimos30Dias;
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class HeatmapPoint {
        private BigDecimal latitude;
        private BigDecimal longitude;
        private BigDecimal scorePrioridade;
        private String categoriaNome;
    }
}
