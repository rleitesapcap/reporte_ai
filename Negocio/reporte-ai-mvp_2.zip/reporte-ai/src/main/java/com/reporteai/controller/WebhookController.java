package com.reporteai.controller;

import com.reporteai.model.dto.EvolutionWebhookPayload;
import com.reporteai.whatsapp.MessageHandler;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Endpoint para receber webhooks da Evolution API (WhatsApp).
 */
@RestController
@RequestMapping("/webhook")
@Slf4j
@RequiredArgsConstructor
public class WebhookController {

    private final MessageHandler messageHandler;

    @Value("${reporteai.whatsapp.webhook.token:changeme}")
    private String webhookToken;

    /**
     * Recebe mensagens do WhatsApp via Evolution API.
     * Endpoint: POST /webhook/whatsapp
     */
    @PostMapping("/whatsapp")
    public ResponseEntity<String> receberWhatsApp(
            @RequestBody EvolutionWebhookPayload payload,
            @RequestHeader(value = "x-webhook-token", required = false) String token) {

        // Validar token (opcional mas recomendado)
        if (webhookToken != null && !webhookToken.equals("changeme")
                && !webhookToken.equals(token)) {
            log.warn("Webhook token inválido");
            return ResponseEntity.status(401).body("Unauthorized");
        }

        // Filtrar apenas eventos de mensagem
        if (payload.getEvent() == null || !payload.getEvent().equals("messages.upsert")) {
            return ResponseEntity.ok("ignored");
        }

        // Processar assíncronamente para não bloquear o webhook
        try {
            messageHandler.processar(payload);
        } catch (Exception e) {
            log.error("Erro ao processar webhook: {}", e.getMessage(), e);
        }

        return ResponseEntity.ok("ok");
    }

    /**
     * Health check do webhook.
     */
    @GetMapping("/whatsapp")
    public ResponseEntity<String> healthCheck() {
        return ResponseEntity.ok("Reporte AI Webhook OK");
    }
}
