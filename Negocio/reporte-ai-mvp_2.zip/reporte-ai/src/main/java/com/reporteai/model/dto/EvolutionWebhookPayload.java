package com.reporteai.model.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * Payload do webhook da Evolution API v2.
 * Representa mensagens recebidas via WhatsApp.
 */
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EvolutionWebhookPayload {

    private String event;           // "messages.upsert"
    private String instance;
    private DataWrapper data;

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DataWrapper {
        private MessageKey key;
        private String pushName;          // nome do contato
        private MessageContent message;
        private String messageType;       // "conversation", "imageMessage", "audioMessage", "locationMessage"
        private Long messageTimestamp;
    }

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MessageKey {
        private String remoteJid;         // "5534999999999@s.whatsapp.net"
        private Boolean fromMe;
        private String id;
    }

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class MessageContent {
        // Texto simples
        private String conversation;

        // Imagem
        private ImageMessage imageMessage;

        // Localização
        private LocationMessage locationMessage;

        // Áudio
        private AudioMessage audioMessage;

        // Texto com mídia (caption)
        private String extendedTextMessage;
    }

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class ImageMessage {
        private String url;
        private String caption;
        private String mimetype;
        private String mediaUrl;
        @JsonProperty("base64")
        private String base64;
    }

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class LocationMessage {
        private Double degreesLatitude;
        private Double degreesLongitude;
        private String name;
        private String address;
    }

    @Getter @Setter @NoArgsConstructor
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class AudioMessage {
        private String url;
        private String mimetype;
        private Boolean ptt;  // push-to-talk (voice note)
    }

    // Helpers
    public String getPhoneNumber() {
        if (data != null && data.getKey() != null && data.getKey().getRemoteJid() != null) {
            return data.getKey().getRemoteJid().replace("@s.whatsapp.net", "");
        }
        return null;
    }

    public String getTextContent() {
        if (data == null || data.getMessage() == null) return null;
        var msg = data.getMessage();
        if (msg.getConversation() != null) return msg.getConversation();
        if (msg.getImageMessage() != null && msg.getImageMessage().getCaption() != null)
            return msg.getImageMessage().getCaption();
        return null;
    }

    public boolean hasImage() {
        return data != null && data.getMessage() != null && data.getMessage().getImageMessage() != null;
    }

    public boolean hasLocation() {
        return data != null && data.getMessage() != null && data.getMessage().getLocationMessage() != null;
    }

    public boolean hasAudio() {
        return data != null && data.getMessage() != null && data.getMessage().getAudioMessage() != null;
    }

    public boolean isFromMe() {
        return data != null && data.getKey() != null && Boolean.TRUE.equals(data.getKey().getFromMe());
    }
}
