package com.reporteai.controller;

import com.reporteai.model.dto.*;
import com.reporteai.model.enums.StatusOcorrencia;
import com.reporteai.model.entity.Usuario;
import com.reporteai.service.OcorrenciaService;
import com.reporteai.service.WhatsAppService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * API REST para ocorrências.
 * Base: /api/v1/ocorrencias
 */
@RestController
@RequestMapping("/api/v1/ocorrencias")
@RequiredArgsConstructor
@CrossOrigin(origins = "*") // MVP - restringir em produção
public class OcorrenciaController {

    private final OcorrenciaService ocorrenciaService;
    private final WhatsAppService whatsAppService;

    /**
     * Criar nova ocorrência via API.
     * POST /api/v1/ocorrencias
     */
    @PostMapping
    public ResponseEntity<OcorrenciaResponse> criar(@Valid @RequestBody OcorrenciaRequest request) {
        // Para API, criar usuário genérico (sem telefone)
        Usuario usuario = whatsAppService.resolverUsuario("api-user-" + System.currentTimeMillis(), null);
        OcorrenciaResponse response = ocorrenciaService.criar(request, usuario);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Buscar por protocolo.
     * GET /api/v1/ocorrencias/protocolo/{protocolo}
     */
    @GetMapping("/protocolo/{protocolo}")
    public ResponseEntity<OcorrenciaResponse> buscarPorProtocolo(@PathVariable String protocolo) {
        return ResponseEntity.ok(ocorrenciaService.buscarPorProtocolo(protocolo));
    }

    /**
     * Listar ocorrências por cidade.
     * GET /api/v1/ocorrencias?cidadeId=1&page=0&size=20
     */
    @GetMapping
    public ResponseEntity<Page<OcorrenciaResponse>> listar(
            @RequestParam(defaultValue = "1") Long cidadeId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ocorrenciaService.listarPorCidade(cidadeId, page, size));
    }

    /**
     * Listar ocorrências abertas (ordenadas por prioridade).
     * GET /api/v1/ocorrencias/abertas?cidadeId=1
     */
    @GetMapping("/abertas")
    public ResponseEntity<Page<OcorrenciaResponse>> listarAbertas(
            @RequestParam(defaultValue = "1") Long cidadeId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        return ResponseEntity.ok(ocorrenciaService.listarAbertas(cidadeId, page, size));
    }

    /**
     * Top N problemas por prioridade.
     * GET /api/v1/ocorrencias/top?cidadeId=1&limit=10
     */
    @GetMapping("/top")
    public ResponseEntity<List<OcorrenciaResponse>> topPrioridade(
            @RequestParam(defaultValue = "1") Long cidadeId,
            @RequestParam(defaultValue = "10") int limit) {
        return ResponseEntity.ok(ocorrenciaService.topPrioridade(cidadeId, limit));
    }

    /**
     * Atualizar status de uma ocorrência.
     * PATCH /api/v1/ocorrencias/{protocolo}/status
     */
    @PatchMapping("/{protocolo}/status")
    public ResponseEntity<OcorrenciaResponse> atualizarStatus(
            @PathVariable String protocolo,
            @RequestBody StatusUpdateRequest request) {
        return ResponseEntity.ok(ocorrenciaService.atualizarStatus(
                protocolo, request.getStatus(), request.getResponsavel(), request.getObservacao()));
    }

    // --- Inner DTO ---

    @lombok.Getter @lombok.Setter @lombok.NoArgsConstructor
    public static class StatusUpdateRequest {
        private StatusOcorrencia status;
        private String responsavel;
        private String observacao;
    }
}
