package com.reporteai.model.enums;

public enum StatusOcorrencia {
    RECEBIDA,
    EM_ANALISE,
    VALIDADA,
    EM_RESOLUCAO,
    RESOLVIDA,
    ARQUIVADA,
    REJEITADA
}
