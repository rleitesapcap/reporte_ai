package com.reporteai.service;

import com.reporteai.model.entity.Usuario;
import com.reporteai.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;

/**
 * Integração com Evolution API para envio/recebimento de mensagens WhatsApp.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class WhatsAppService {

    private final UsuarioRepository usuarioRepository;

    @Value("${reporteai.whatsapp.evolution.base-url:http://localhost:8080}")
    private String evolutionBaseUrl;

    @Value("${reporteai.whatsapp.evolution.api-key:}")
    private String evolutionApiKey;

    @Value("${reporteai.whatsapp.evolution.instance-name:reporteai}")
    private String instanceName;

    private WebClient webClient;

    private WebClient getWebClient() {
        if (webClient == null) {
            webClient = WebClient.builder()
                    .baseUrl(evolutionBaseUrl)
                    .defaultHeader("apikey", evolutionApiKey)
                    .build();
        }
        return webClient;
    }

    /**
     * Envia mensagem de texto via WhatsApp.
     */
    public void enviarMensagem(String telefone, String texto) {
        String jid = telefone.contains("@") ? telefone : telefone + "@s.whatsapp.net";

        String body = """
                {
                    "number": "%s",
                    "text": "%s"
                }
                """.formatted(jid, escapeJson(texto));

        try {
            getWebClient()
                    .post()
                    .uri("/message/sendText/{instance}", instanceName)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            log.debug("Mensagem enviada para {}", telefone);
        } catch (Exception e) {
            log.error("Erro ao enviar mensagem WhatsApp para {}: {}", telefone, e.getMessage());
        }
    }

    /**
     * Envia mensagem com botões (lista de opções).
     */
    public void enviarListaOpcoes(String telefone, String titulo, String descricao,
                                    String botaoTexto, java.util.List<String> opcoes) {
        StringBuilder rows = new StringBuilder();
        for (int i = 0; i < opcoes.size(); i++) {
            if (i > 0) rows.append(",");
            rows.append("""
                    {"title": "%s", "rowId": "%d"}""".formatted(escapeJson(opcoes.get(i)), i + 1));
        }

        String body = """
                {
                    "number": "%s",
                    "title": "%s",
                    "description": "%s",
                    "buttonText": "%s",
                    "sections": [
                        {
                            "title": "Opções",
                            "rows": [%s]
                        }
                    ]
                }
                """.formatted(
                telefone + "@s.whatsapp.net",
                escapeJson(titulo),
                escapeJson(descricao),
                escapeJson(botaoTexto),
                rows.toString()
        );

        try {
            getWebClient()
                    .post()
                    .uri("/message/sendList/{instance}", instanceName)
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(body)
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();
        } catch (Exception e) {
            log.error("Erro ao enviar lista WhatsApp: {}", e.getMessage());
            // Fallback: enviar como texto simples
            StringBuilder textoFallback = new StringBuilder(titulo + "\n\n");
            for (int i = 0; i < opcoes.size(); i++) {
                textoFallback.append(String.format("%d. %s\n", i + 1, opcoes.get(i)));
            }
            textoFallback.append("\nResponda com o número da opção.");
            enviarMensagem(telefone, textoFallback.toString());
        }
    }

    /**
     * Busca ou cria usuário baseado no telefone (hash SHA-256 para LGPD).
     */
    public Usuario resolverUsuario(String telefone, Long cidadeId) {
        String hash = hashTelefone(telefone);
        return usuarioRepository.findByHashTelefone(hash)
                .orElseGet(() -> {
                    Usuario novo = Usuario.builder()
                            .hashTelefone(hash)
                            .build();
                    return usuarioRepository.save(novo);
                });
    }

    /**
     * Hash SHA-256 do telefone para LGPD compliance.
     */
    public String hashTelefone(String telefone) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(telefone.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao gerar hash do telefone", e);
        }
    }

    private String escapeJson(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
