package com.reporteai.model.dto;

import com.reporteai.model.enums.*;
import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

// ============================================================================
// REQUEST DTOs
// ============================================================================

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OcorrenciaRequest {

    @NotBlank(message = "Descrição é obrigatória")
    private String descricao;

    private Long categoriaId;
    private Long subcategoriaId;

    private BigDecimal latitude;
    private BigDecimal longitude;
    private String enderecoTexto;
    private Long bairroId;

    private GravidadeOcorrencia gravidade;
    private Integer frequencia;

    private String fotoUrl;
    private CanalEntrada canal;
    private Long cidadeId;
}
