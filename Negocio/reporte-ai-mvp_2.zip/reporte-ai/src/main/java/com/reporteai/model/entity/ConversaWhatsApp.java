package com.reporteai.model.entity;

import com.reporteai.model.enums.EstadoConversa;
import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "conversas_whatsapp")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ConversaWhatsApp {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cidade_id", nullable = false)
    private Cidade cidade;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado_atual", nullable = false, length = 50)
    @Builder.Default
    private EstadoConversa estadoAtual = EstadoConversa.INICIO;

    @Column(name = "dados_parciais", columnDefinition = "jsonb")
    @Builder.Default
    private String dadosParciais = "{}";

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ocorrencia_id")
    private Ocorrencia ocorrencia;

    @Column(length = 20)
    @Builder.Default
    private String modo = "GUIADO";

    @Builder.Default
    private Boolean expirada = false;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
        updatedAt = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }

    public boolean isExpirada(int timeoutMinutos) {
        return updatedAt != null &&
               updatedAt.plusMinutes(timeoutMinutos).isBefore(OffsetDateTime.now());
    }
}
