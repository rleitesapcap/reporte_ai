package com.reporteai.model.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "cidades")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Cidade {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String nome;

    @Column(nullable = false, length = 2)
    private String uf;

    @Column(name = "ibge_codigo", unique = true, length = 7)
    private String ibgeCodigo;

    private Integer populacao;

    @Column(name = "area_km2")
    private BigDecimal areaKm2;

    @Builder.Default
    private Boolean turistica = false;

    @Builder.Default
    private Boolean ativa = false;

    @Builder.Default
    @Column(length = 50)
    private String plano = "COMUNIDADE";

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
        updatedAt = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
