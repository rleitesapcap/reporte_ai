package com.reporteai.whatsapp;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.reporteai.model.dto.EvolutionWebhookPayload;
import com.reporteai.model.dto.OcorrenciaRequest;
import com.reporteai.model.entity.*;
import com.reporteai.model.enums.*;
import com.reporteai.repository.*;
import com.reporteai.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.*;

/**
 * Máquina de estados para conversas WhatsApp.
 * 
 * Suporta dois modos:
 * - GUIADO: Bot pergunta passo a passo (categoria → descrição → localização → gravidade → foto → confirma)
 * - RÁPIDO: Usuário manda tudo em 1 mensagem (texto + foto + localização), IA classifica
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class MessageHandler {

    private final WhatsAppService whatsAppService;
    private final OcorrenciaService ocorrenciaService;
    private final CategoriaRepository categoriaRepository;
    private final ConversaWhatsAppRepository conversaRepository;
    private final CidadeRepository cidadeRepository;
    private final ObjectMapper objectMapper;

    @Value("${reporteai.conversa.timeout-minutos:30}")
    private int timeoutMinutos;

    @Value("${reporteai.cidade-padrao-id:1}")
    private Long cidadePadraoId;

    private static final String MSG_BOAS_VINDAS = """
            🏙️ *Reporte AI - Inteligência Comunitária*
            
            Olá, %s! Eu sou o bot do Reporte AI.
            Aqui você pode reportar problemas da cidade e acompanhar soluções.
            
            Como deseja prosseguir?
            
            1️⃣ *Reportar problema* (passo a passo)
            2️⃣ *Modo rápido* (envie foto + localização + descrição)
            3️⃣ *Consultar protocolo*
            4️⃣ *Ajuda*
            
            Responda com o número da opção.""";

    private static final String MSG_CATEGORIAS = """
            📋 *Qual a categoria do problema?*
            
            1. 🗑️ Lixo e Resíduos
            2. 💡 Iluminação Pública
            3. 🕳️ Buracos e Pavimentação
            4. 💧 Água e Esgoto
            5. 🌿 Vegetação e Áreas Verdes
            6. 🚦 Trânsito e Sinalização
            7. 🛡️ Segurança Pública
            8. 🐾 Animais
            9. 🌫️ Poluição
            10. ♿ Acessibilidade
            11. 📸 Infraestrutura Turística
            12. ❓ Outros
            
            Responda com o número.""";

    private static final String MSG_DESCRICAO = "📝 *Descreva o problema* com o máximo de detalhes possível:";
    private static final String MSG_LOCALIZACAO = "📍 *Envie a localização* do problema.\n\nVocê pode:\n• Enviar a localização pelo WhatsApp (clipe > Localização)\n• Digitar o endereço ou referência (ex: Rua das Flores, próximo ao posto)";
    private static final String MSG_GRAVIDADE = "⚠️ *Qual a gravidade?*\n\n1. Baixa\n2. Média\n3. Alta\n4. Crítica\n\nResponda com o número.";
    private static final String MSG_FOTO = "📷 *Tem foto do problema?*\n\nEnvie a foto agora ou digite *pular* para continuar sem foto.";

    /**
     * Processa mensagem recebida do WhatsApp.
     */
    public void processar(EvolutionWebhookPayload payload) {
        if (payload.isFromMe()) return; // Ignora mensagens enviadas por nós

        String telefone = payload.getPhoneNumber();
        String texto = payload.getTextContent();
        String pushName = payload.getData() != null ? payload.getData().getPushName() : "Cidadão";

        if (telefone == null) {
            log.warn("Mensagem sem telefone, ignorando");
            return;
        }

        log.info("Mensagem recebida de {}: {}", telefone, texto != null ? texto.substring(0, Math.min(50, texto.length())) : "[mídia]");

        // Resolver usuário
        Usuario usuario = whatsAppService.resolverUsuario(telefone, cidadePadraoId);

        // Detectar modo rápido: mensagem com foto + localização
        if (isModoRapido(payload)) {
            processarModoRapido(payload, usuario, telefone);
            return;
        }

        // Buscar conversa ativa
        ConversaWhatsApp conversa = conversaRepository
                .findTopByUsuarioIdAndExpiradaFalseOrderByUpdatedAtDesc(usuario.getId())
                .orElse(null);

        // Expirar conversa antiga
        if (conversa != null && conversa.isExpirada(timeoutMinutos)) {
            conversa.setExpirada(true);
            conversaRepository.save(conversa);
            conversa = null;
        }

        // Nova conversa
        if (conversa == null) {
            // Verificar se é consulta de protocolo
            if (texto != null && texto.toUpperCase().startsWith("RPT-")) {
                consultarProtocolo(telefone, texto.trim().toUpperCase());
                return;
            }

            whatsAppService.enviarMensagem(telefone, String.format(MSG_BOAS_VINDAS, pushName));

            Cidade cidade = cidadeRepository.findById(cidadePadraoId).orElse(null);
            conversa = ConversaWhatsApp.builder()
                    .usuario(usuario)
                    .cidade(cidade)
                    .estadoAtual(EstadoConversa.INICIO)
                    .build();
            conversaRepository.save(conversa);
            return;
        }

        // Processar estado atual
        processarEstado(conversa, payload, usuario, telefone);
    }

    /**
     * Detecta se a mensagem é modo rápido (foto + localização ou foto + texto descritivo).
     */
    private boolean isModoRapido(EvolutionWebhookPayload payload) {
        return payload.hasImage() && (payload.hasLocation() || payload.getTextContent() != null);
    }

    /**
     * Processa modo rápido: foto + localização + texto em 1 mensagem.
     */
    private void processarModoRapido(EvolutionWebhookPayload payload, Usuario usuario, String telefone) {
        log.info("Modo rápido detectado para {}", telefone);

        String descricao = payload.getTextContent();
        if (descricao == null || descricao.isBlank()) {
            descricao = "Problema reportado via foto (sem descrição)";
        }

        BigDecimal lat = null, lng = null;
        String endereco = null;

        if (payload.hasLocation()) {
            var loc = payload.getData().getMessage().getLocationMessage();
            lat = BigDecimal.valueOf(loc.getDegreesLatitude());
            lng = BigDecimal.valueOf(loc.getDegreesLongitude());
            endereco = loc.getAddress();
        }

        String fotoUrl = null;
        if (payload.hasImage()) {
            var img = payload.getData().getMessage().getImageMessage();
            fotoUrl = img.getMediaUrl() != null ? img.getMediaUrl() : img.getUrl();
            // Se tem caption na imagem, usar como descrição
            if (img.getCaption() != null && !img.getCaption().isBlank()) {
                descricao = img.getCaption();
            }
        }

        OcorrenciaRequest request = OcorrenciaRequest.builder()
                .descricao(descricao)
                .latitude(lat)
                .longitude(lng)
                .enderecoTexto(endereco)
                .fotoUrl(fotoUrl)
                .canal(CanalEntrada.WHATSAPP_RAPIDO)
                .cidadeId(cidadePadraoId)
                .build();

        var response = ocorrenciaService.criar(request, usuario);

        String confirmacao = """
                ✅ *Ocorrência registrada com sucesso!*
                
                📋 Protocolo: *%s*
                🏷️ Categoria: %s
                ⚠️ Prioridade: %.1f
                
                Acompanhe o status enviando o número do protocolo a qualquer momento.
                
                Obrigado por contribuir com a sua cidade! 🏙️
                """.formatted(
                response.getProtocolo(),
                response.getCategoriaNome() != null ? response.getCategoriaNome() : "Classificando...",
                response.getScorePrioridade()
        );

        whatsAppService.enviarMensagem(telefone, confirmacao);
    }

    /**
     * Processa o estado atual da conversa guiada.
     */
    private void processarEstado(ConversaWhatsApp conversa, EvolutionWebhookPayload payload,
                                   Usuario usuario, String telefone) {
        String texto = payload.getTextContent();
        Map<String, Object> dados = parseDados(conversa.getDadosParciais());

        switch (conversa.getEstadoAtual()) {
            case INICIO -> {
                if (texto == null) return;
                switch (texto.trim()) {
                    case "1" -> {
                        whatsAppService.enviarMensagem(telefone, MSG_CATEGORIAS);
                        conversa.setEstadoAtual(EstadoConversa.AGUARDANDO_CATEGORIA);
                    }
                    case "2" -> {
                        whatsAppService.enviarMensagem(telefone,
                                "📸 *Modo Rápido*\n\nEnvie uma foto do problema junto com a localização e uma descrição.\n\nDica: Anexe a foto, escreva na legenda e compartilhe a localização.");
                        conversa.setExpirada(true); // Modo rápido não usa fluxo guiado
                    }
                    case "3" -> {
                        whatsAppService.enviarMensagem(telefone, "🔍 Digite o número do protocolo (ex: RPT-2026-00001):");
                        conversa.setEstadoAtual(EstadoConversa.CONSULTA_PROTOCOLO);
                    }
                    case "4" -> {
                        whatsAppService.enviarMensagem(telefone, """
                                ℹ️ *Ajuda - Reporte AI*
                                
                                O Reporte AI é uma plataforma de inteligência comunitária.
                                
                                • Reporte problemas da sua cidade pelo WhatsApp
                                • Acompanhe o status pelo número de protocolo
                                • Seus dados são anônimos e protegidos (LGPD)
                                
                                Para começar, envie qualquer mensagem.""");
                        conversa.setExpirada(true);
                    }
                    default -> whatsAppService.enviarMensagem(telefone, "Por favor, responda com 1, 2, 3 ou 4.");
                }
            }

            case AGUARDANDO_CATEGORIA -> {
                if (texto == null) return;
                try {
                    int opcao = Integer.parseInt(texto.trim());
                    if (opcao < 1 || opcao > 12) throw new NumberFormatException();

                    List<Categoria> categorias = categoriaRepository.findByAtivaTrue();
                    if (opcao <= categorias.size()) {
                        Categoria cat = categorias.get(opcao - 1);
                        dados.put("categoriaId", cat.getId());
                        dados.put("categoriaNome", cat.getNome());
                        salvarDados(conversa, dados);

                        whatsAppService.enviarMensagem(telefone, MSG_DESCRICAO);
                        conversa.setEstadoAtual(EstadoConversa.AGUARDANDO_DESCRICAO);
                    }
                } catch (NumberFormatException e) {
                    whatsAppService.enviarMensagem(telefone, "⚠️ Opção inválida. Responda com um número de 1 a 12.");
                }
            }

            case AGUARDANDO_DESCRICAO -> {
                if (texto == null || texto.isBlank()) {
                    whatsAppService.enviarMensagem(telefone, "⚠️ Por favor, descreva o problema.");
                    return;
                }
                dados.put("descricao", texto);
                salvarDados(conversa, dados);

                whatsAppService.enviarMensagem(telefone, MSG_LOCALIZACAO);
                conversa.setEstadoAtual(EstadoConversa.AGUARDANDO_LOCALIZACAO);
            }

            case AGUARDANDO_LOCALIZACAO -> {
                if (payload.hasLocation()) {
                    var loc = payload.getData().getMessage().getLocationMessage();
                    dados.put("latitude", loc.getDegreesLatitude());
                    dados.put("longitude", loc.getDegreesLongitude());
                    if (loc.getAddress() != null) dados.put("endereco", loc.getAddress());
                } else if (texto != null && !texto.isBlank()) {
                    dados.put("endereco", texto);
                } else {
                    whatsAppService.enviarMensagem(telefone, "⚠️ Envie a localização ou digite o endereço.");
                    return;
                }
                salvarDados(conversa, dados);

                whatsAppService.enviarMensagem(telefone, MSG_GRAVIDADE);
                conversa.setEstadoAtual(EstadoConversa.AGUARDANDO_GRAVIDADE);
            }

            case AGUARDANDO_GRAVIDADE -> {
                if (texto == null) return;
                GravidadeOcorrencia gravidade = switch (texto.trim()) {
                    case "1" -> GravidadeOcorrencia.BAIXA;
                    case "2" -> GravidadeOcorrencia.MEDIA;
                    case "3" -> GravidadeOcorrencia.ALTA;
                    case "4" -> GravidadeOcorrencia.CRITICA;
                    default -> null;
                };
                if (gravidade == null) {
                    whatsAppService.enviarMensagem(telefone, "⚠️ Responda com 1, 2, 3 ou 4.");
                    return;
                }
                dados.put("gravidade", gravidade.name());
                salvarDados(conversa, dados);

                whatsAppService.enviarMensagem(telefone, MSG_FOTO);
                conversa.setEstadoAtual(EstadoConversa.AGUARDANDO_FOTO);
            }

            case AGUARDANDO_FOTO -> {
                if (payload.hasImage()) {
                    var img = payload.getData().getMessage().getImageMessage();
                    String fotoUrl = img.getMediaUrl() != null ? img.getMediaUrl() : img.getUrl();
                    dados.put("fotoUrl", fotoUrl);
                } else if (texto != null && texto.toLowerCase().contains("pular")) {
                    // Sem foto
                } else {
                    whatsAppService.enviarMensagem(telefone, "📷 Envie a foto ou digite *pular*.");
                    return;
                }
                salvarDados(conversa, dados);

                // Mostrar resumo para confirmação
                String resumo = """
                        📋 *Resumo da ocorrência:*
                        
                        🏷️ Categoria: %s
                        📝 Descrição: %s
                        📍 Local: %s
                        ⚠️ Gravidade: %s
                        📷 Foto: %s
                        
                        Confirma o registro? Responda *sim* ou *não*.
                        """.formatted(
                        dados.getOrDefault("categoriaNome", "—"),
                        truncar((String) dados.getOrDefault("descricao", "—"), 100),
                        dados.containsKey("latitude") ? "📌 Localização enviada" : dados.getOrDefault("endereco", "—"),
                        dados.getOrDefault("gravidade", "MEDIA"),
                        dados.containsKey("fotoUrl") ? "✅ Sim" : "❌ Não"
                );

                whatsAppService.enviarMensagem(telefone, resumo);
                conversa.setEstadoAtual(EstadoConversa.CONFIRMACAO);
            }

            case CONFIRMACAO -> {
                if (texto == null) return;
                if (texto.toLowerCase().startsWith("sim") || texto.equals("s")) {
                    // Criar ocorrência
                    OcorrenciaRequest request = OcorrenciaRequest.builder()
                            .descricao((String) dados.get("descricao"))
                            .categoriaId(dados.containsKey("categoriaId") ? ((Number) dados.get("categoriaId")).longValue() : null)
                            .latitude(dados.containsKey("latitude") ? BigDecimal.valueOf((Double) dados.get("latitude")) : null)
                            .longitude(dados.containsKey("longitude") ? BigDecimal.valueOf((Double) dados.get("longitude")) : null)
                            .enderecoTexto((String) dados.get("endereco"))
                            .gravidade(dados.containsKey("gravidade") ? GravidadeOcorrencia.valueOf((String) dados.get("gravidade")) : GravidadeOcorrencia.MEDIA)
                            .fotoUrl((String) dados.get("fotoUrl"))
                            .canal(CanalEntrada.WHATSAPP_GUIADO)
                            .cidadeId(cidadePadraoId)
                            .build();

                    var response = ocorrenciaService.criar(request, usuario);

                    whatsAppService.enviarMensagem(telefone, """
                            ✅ *Ocorrência registrada!*
                            
                            📋 Protocolo: *%s*
                            ⚠️ Score de prioridade: %.1f
                            
                            Guarde seu protocolo para acompanhar o status.
                            Obrigado por contribuir! 🏙️
                            """.formatted(response.getProtocolo(), response.getScorePrioridade()));

                    conversa.setEstadoAtual(EstadoConversa.FINALIZADA);
                    conversa.setExpirada(true);
                } else {
                    whatsAppService.enviarMensagem(telefone, "❌ Registro cancelado. Envie qualquer mensagem para começar de novo.");
                    conversa.setEstadoAtual(EstadoConversa.CANCELADA);
                    conversa.setExpirada(true);
                }
            }

            case CONSULTA_PROTOCOLO -> {
                if (texto == null) return;
                consultarProtocolo(telefone, texto.trim().toUpperCase());
                conversa.setExpirada(true);
            }

            default -> {
                conversa.setExpirada(true);
            }
        }

        conversaRepository.save(conversa);
    }

    /**
     * Consulta status de um protocolo.
     */
    private void consultarProtocolo(String telefone, String protocolo) {
        try {
            var response = ocorrenciaService.buscarPorProtocolo(protocolo);
            String statusEmoji = switch (response.getStatus()) {
                case RECEBIDA -> "📥";
                case EM_ANALISE -> "🔍";
                case VALIDADA -> "✅";
                case EM_RESOLUCAO -> "🔧";
                case RESOLVIDA -> "🎉";
                case ARQUIVADA -> "📦";
                case REJEITADA -> "❌";
            };

            whatsAppService.enviarMensagem(telefone, """
                    🔍 *Status do Protocolo %s*
                    
                    %s Status: *%s*
                    🏷️ Categoria: %s
                    📝 %s
                    📅 Registrado em: %s
                    """.formatted(
                    protocolo,
                    statusEmoji, response.getStatus().name().replace("_", " "),
                    response.getCategoriaNome() != null ? response.getCategoriaNome() : "—",
                    truncar(response.getDescricao(), 80),
                    response.getDataRegistro() != null ? response.getDataRegistro().toLocalDate().toString() : "—"
            ));
        } catch (Exception e) {
            whatsAppService.enviarMensagem(telefone,
                    "⚠️ Protocolo *" + protocolo + "* não encontrado. Verifique o número e tente novamente.");
        }
    }

    // --- Helpers ---

    @SuppressWarnings("unchecked")
    private Map<String, Object> parseDados(String json) {
        try {
            if (json == null || json.isBlank() || json.equals("{}")) return new HashMap<>();
            return objectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (Exception e) {
            return new HashMap<>();
        }
    }

    private void salvarDados(ConversaWhatsApp conversa, Map<String, Object> dados) {
        try {
            conversa.setDadosParciais(objectMapper.writeValueAsString(dados));
        } catch (Exception e) {
            log.error("Erro ao serializar dados parciais", e);
        }
    }

    private String truncar(String texto, int max) {
        if (texto == null) return "—";
        return texto.length() > max ? texto.substring(0, max) + "..." : texto;
    }
}
