package com.reporteai.repository;

import com.reporteai.model.entity.HistoricoStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface HistoricoStatusRepository extends JpaRepository<HistoricoStatus, Long> {
    List<HistoricoStatus> findByOcorrenciaIdOrderByCreatedAtDesc(Long ocorrenciaId);
}
