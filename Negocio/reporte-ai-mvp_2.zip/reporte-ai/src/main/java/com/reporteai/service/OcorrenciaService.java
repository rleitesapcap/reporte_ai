package com.reporteai.service;

import com.reporteai.model.dto.*;
import com.reporteai.model.entity.*;
import com.reporteai.model.enums.*;
import com.reporteai.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

/**
 * Serviço principal de ocorrências.
 * Orquestra: protocolo -> classificação -> dedup -> score -> persistência -> histórico.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class OcorrenciaService {

    private final OcorrenciaRepository ocorrenciaRepository;
    private final HistoricoStatusRepository historicoRepository;
    private final CidadeRepository cidadeRepository;
    private final CategoriaRepository categoriaRepository;
    private final SubcategoriaRepository subcategoriaRepository;
    private final UsuarioRepository usuarioRepository;

    private final ProtocoloService protocoloService;
    private final ClassificacaoService classificacaoService;
    private final ScoreService scoreService;
    private final DeduplicacaoService deduplicacaoService;

    @Value("${reporteai.cidade-padrao-id:1}")
    private Long cidadePadraoId;

    // =========================================================================
    // CRIAR OCORRÊNCIA (pipeline completo)
    // =========================================================================

    @Transactional
    public OcorrenciaResponse criar(OcorrenciaRequest request, Usuario usuario) {
        log.info("Criando nova ocorrência para usuário {}", usuario.getId());

        // 1. Resolver cidade
        Long cidadeId = request.getCidadeId() != null ? request.getCidadeId() : cidadePadraoId;
        Cidade cidade = cidadeRepository.findById(cidadeId)
                .orElseThrow(() -> new IllegalArgumentException("Cidade não encontrada: " + cidadeId));

        // 2. Gerar protocolo
        String protocolo = protocoloService.gerarProtocolo();

        // 3. Montar entidade
        Ocorrencia ocorrencia = Ocorrencia.builder()
                .protocolo(protocolo)
                .cidade(cidade)
                .usuario(usuario)
                .descricao(request.getDescricao())
                .latitude(request.getLatitude())
                .longitude(request.getLongitude())
                .enderecoTexto(request.getEnderecoTexto())
                .gravidade(request.getGravidade() != null ? request.getGravidade() : GravidadeOcorrencia.MEDIA)
                .frequencia(request.getFrequencia() != null ? request.getFrequencia() : 1)
                .fotoUrl(request.getFotoUrl())
                .canal(request.getCanal() != null ? request.getCanal() : CanalEntrada.API)
                .status(StatusOcorrencia.RECEBIDA)
                .build();

        // 4. Classificação automática
        if (request.getCategoriaId() == null) {
            ClassificacaoService.ClassificacaoResult classResult =
                    classificacaoService.classificar(request.getDescricao());

            if (classResult.categoriaId() != null) {
                categoriaRepository.findById(classResult.categoriaId())
                        .ifPresent(ocorrencia::setCategoria);
            }
            if (classResult.subcategoriaId() != null) {
                subcategoriaRepository.findById(classResult.subcategoriaId())
                        .ifPresent(ocorrencia::setSubcategoria);
            }
            ocorrencia.setClassificadoPorIa(classResult.classificadoPorIa());
            ocorrencia.setConfiancaClassIa(BigDecimal.valueOf(classResult.confianca()));
        } else {
            categoriaRepository.findById(request.getCategoriaId())
                    .ifPresent(ocorrencia::setCategoria);
            if (request.getSubcategoriaId() != null) {
                subcategoriaRepository.findById(request.getSubcategoriaId())
                        .ifPresent(ocorrencia::setSubcategoria);
            }
        }

        // 5. Geocodificação
        if (ocorrencia.getLatitude() != null && ocorrencia.getLongitude() != null) {
            ocorrencia.setGeocodificado(true);
        }

        // 6. Score de prioridade
        scoreService.calcular(ocorrencia);

        // 7. Persistir
        ocorrencia = ocorrenciaRepository.save(ocorrencia);

        // 8. Deduplicação (após persistir para ter ID)
        DeduplicacaoService.DeduplicacaoResult dedupResult = deduplicacaoService.verificar(ocorrencia);
        if (dedupResult.isDuplicata()) {
            deduplicacaoService.registrarDuplicata(dedupResult.ocorrenciaPai(), ocorrencia, dedupResult.similaridade());
            // Recalcular score do pai com nova reincidência
            scoreService.calcular(dedupResult.ocorrenciaPai());
            ocorrenciaRepository.save(dedupResult.ocorrenciaPai());
            ocorrenciaRepository.save(ocorrencia);
        }

        // 9. Histórico de status
        registrarHistorico(ocorrencia, null, StatusOcorrencia.RECEBIDA, "Sistema", "Ocorrência registrada");

        // 10. Atualizar stats do usuário
        usuario.incrementarReportes();
        usuarioRepository.save(usuario);

        log.info("Ocorrência criada: {} (score={})", protocolo, ocorrencia.getScorePrioridade());
        return toResponse(ocorrencia);
    }

    // =========================================================================
    // CONSULTAS
    // =========================================================================

    public OcorrenciaResponse buscarPorProtocolo(String protocolo) {
        return ocorrenciaRepository.findByProtocolo(protocolo)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Protocolo não encontrado: " + protocolo));
    }

    public Page<OcorrenciaResponse> listarPorCidade(Long cidadeId, int page, int size) {
        return ocorrenciaRepository.findByCidadeIdOrderByDataRegistroDesc(cidadeId, PageRequest.of(page, size))
                .map(this::toResponse);
    }

    public Page<OcorrenciaResponse> listarAbertas(Long cidadeId, int page, int size) {
        return ocorrenciaRepository.findByCidadeIdAndStatusOrderByScorePrioridadeDesc(
                cidadeId, StatusOcorrencia.RECEBIDA, PageRequest.of(page, size))
                .map(this::toResponse);
    }

    public List<OcorrenciaResponse> topPrioridade(Long cidadeId, int limit) {
        return ocorrenciaRepository.findTopPrioridade(cidadeId, PageRequest.of(0, limit))
                .stream().map(this::toResponse).toList();
    }

    // =========================================================================
    // ATUALIZAR STATUS
    // =========================================================================

    @Transactional
    public OcorrenciaResponse atualizarStatus(String protocolo, StatusOcorrencia novoStatus,
                                               String responsavel, String observacao) {
        Ocorrencia ocorrencia = ocorrenciaRepository.findByProtocolo(protocolo)
                .orElseThrow(() -> new IllegalArgumentException("Protocolo não encontrado: " + protocolo));

        StatusOcorrencia statusAnterior = ocorrencia.getStatus();
        ocorrencia.setStatus(novoStatus);

        if (novoStatus == StatusOcorrencia.VALIDADA) {
            ocorrencia.setDataValidacao(OffsetDateTime.now());
        } else if (novoStatus == StatusOcorrencia.RESOLVIDA) {
            ocorrencia.setDataResolucao(OffsetDateTime.now());
        }

        registrarHistorico(ocorrencia, statusAnterior, novoStatus, responsavel, observacao);
        ocorrencia = ocorrenciaRepository.save(ocorrencia);

        log.info("Status atualizado: {} -> {} -> {}", protocolo, statusAnterior, novoStatus);
        return toResponse(ocorrencia);
    }

    // =========================================================================
    // DASHBOARD
    // =========================================================================

    public DashboardSummary getDashboard(Long cidadeId) {
        long total = ocorrenciaRepository.countByCidadeId(cidadeId);
        long resolvidas = ocorrenciaRepository.countByCidadeIdAndStatus(cidadeId, StatusOcorrencia.RESOLVIDA);
        long abertas = total - resolvidas
                - ocorrenciaRepository.countByCidadeIdAndStatus(cidadeId, StatusOcorrencia.ARQUIVADA)
                - ocorrenciaRepository.countByCidadeIdAndStatus(cidadeId, StatusOcorrencia.REJEITADA);

        BigDecimal taxaResolucao = total > 0
                ? BigDecimal.valueOf(100.0 * resolvidas / total).setScale(1, java.math.RoundingMode.HALF_UP)
                : BigDecimal.ZERO;

        Double tempoMedio = ocorrenciaRepository.findTempoMedioResolucao(cidadeId);

        // Ranking de categorias
        List<DashboardSummary.CategoriaRanking> ranking = ocorrenciaRepository.findRankingCategorias(cidadeId)
                .stream()
                .map(row -> DashboardSummary.CategoriaRanking.builder()
                        .categoriaNome((String) row[0])
                        .cor((String) row[1])
                        .total(((Number) row[2]).longValue())
                        .scoreMedio(row[3] != null ? new BigDecimal(row[3].toString()) : BigDecimal.ZERO)
                        .ultimos7Dias(((Number) row[4]).longValue())
                        .ultimos30Dias(((Number) row[5]).longValue())
                        .build())
                .toList();

        // Heatmap
        List<DashboardSummary.HeatmapPoint> heatmap = ocorrenciaRepository
                .findHeatmapData(cidadeId, OffsetDateTime.now().minusDays(90))
                .stream()
                .map(row -> DashboardSummary.HeatmapPoint.builder()
                        .latitude(new BigDecimal(row[0].toString()))
                        .longitude(new BigDecimal(row[1].toString()))
                        .scorePrioridade(row[2] != null ? new BigDecimal(row[2].toString()) : BigDecimal.ZERO)
                        .categoriaNome(row[3] != null ? (String) row[3] : "Outros")
                        .build())
                .toList();

        return DashboardSummary.builder()
                .totalOcorrencias(total)
                .totalAbertas(abertas)
                .totalResolvidas(resolvidas)
                .taxaResolucao(taxaResolucao)
                .tempoMedioResolucaoDias(tempoMedio != null ? BigDecimal.valueOf(tempoMedio) : null)
                .usuariosUnicos(ocorrenciaRepository.countUsuariosUnicosByCidade(cidadeId))
                .bairrosCobertos(ocorrenciaRepository.countBairrosCobertos(cidadeId))
                .rankingCategorias(ranking)
                .heatmapData(heatmap)
                .build();
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private void registrarHistorico(Ocorrencia ocorrencia, StatusOcorrencia anterior,
                                     StatusOcorrencia novo, String responsavel, String obs) {
        HistoricoStatus historico = HistoricoStatus.builder()
                .ocorrencia(ocorrencia)
                .statusAnterior(anterior)
                .statusNovo(novo)
                .responsavel(responsavel)
                .observacao(obs)
                .build();
        historicoRepository.save(historico);
    }

    private OcorrenciaResponse toResponse(Ocorrencia o) {
        return OcorrenciaResponse.builder()
                .id(o.getId())
                .protocolo(o.getProtocolo())
                .categoriaNome(o.getCategoria() != null ? o.getCategoria().getNome() : null)
                .categoriaCor(o.getCategoria() != null ? o.getCategoria().getCor() : null)
                .subcategoriaNome(o.getSubcategoria() != null ? o.getSubcategoria().getNome() : null)
                .descricao(o.getDescricao())
                .latitude(o.getLatitude())
                .longitude(o.getLongitude())
                .bairroNome(o.getBairro() != null ? o.getBairro().getNome() : null)
                .enderecoTexto(o.getEnderecoTexto())
                .gravidade(o.getGravidade())
                .scorePrioridade(o.getScorePrioridade())
                .scoreConfianca(o.getScoreConfianca())
                .reincidencia(o.getReincidencia())
                .fotoUrl(o.getFotoUrl())
                .status(o.getStatus())
                .canal(o.getCanal())
                .dataRegistro(o.getDataRegistro())
                .dataResolucao(o.getDataResolucao())
                .build();
    }
}
