package com.reporteai.repository;

import com.reporteai.model.entity.Ocorrencia;
import com.reporteai.model.enums.StatusOcorrencia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface OcorrenciaRepository extends JpaRepository<Ocorrencia, Long> {

    Optional<Ocorrencia> findByProtocolo(String protocolo);

    Page<Ocorrencia> findByCidadeIdOrderByDataRegistroDesc(Long cidadeId, Pageable pageable);

    Page<Ocorrencia> findByCidadeIdAndStatusOrderByScorePrioridadeDesc(
            Long cidadeId, StatusOcorrencia status, Pageable pageable);

    Page<Ocorrencia> findByCidadeIdAndCategoriaIdOrderByDataRegistroDesc(
            Long cidadeId, Long categoriaId, Pageable pageable);

    long countByCidadeId(Long cidadeId);

    long countByCidadeIdAndStatus(Long cidadeId, StatusOcorrencia status);

    @Query("SELECT COUNT(DISTINCT o.usuario) FROM Ocorrencia o WHERE o.cidade.id = :cidadeId")
    long countUsuariosUnicosByCidade(@Param("cidadeId") Long cidadeId);

    @Query("SELECT COUNT(DISTINCT o.bairro) FROM Ocorrencia o WHERE o.cidade.id = :cidadeId AND o.bairro IS NOT NULL")
    long countBairrosCobertos(@Param("cidadeId") Long cidadeId);

    // Busca por proximidade geográfica para deduplicação
    @Query(value = """
            SELECT o.* FROM ocorrencias o
            WHERE o.cidade_id = :cidadeId
              AND o.status NOT IN ('RESOLVIDA', 'ARQUIVADA', 'REJEITADA')
              AND o.geom IS NOT NULL
              AND ST_DWithin(
                  o.geom::geography,
                  ST_SetSRID(ST_MakePoint(:lng, :lat), 4326)::geography,
                  :raioMetros
              )
              AND o.data_registro >= :desde
            ORDER BY ST_Distance(
                o.geom::geography,
                ST_SetSRID(ST_MakePoint(:lng, :lat), 4326)::geography
            )
            """, nativeQuery = true)
    List<Ocorrencia> findProximas(
            @Param("cidadeId") Long cidadeId,
            @Param("lat") double lat,
            @Param("lng") double lng,
            @Param("raioMetros") double raioMetros,
            @Param("desde") OffsetDateTime desde);

    // Top N por score de prioridade (para dashboard)
    @Query("""
            SELECT o FROM Ocorrencia o
            WHERE o.cidade.id = :cidadeId
              AND o.status NOT IN (
                  com.reporteai.model.enums.StatusOcorrencia.RESOLVIDA,
                  com.reporteai.model.enums.StatusOcorrencia.ARQUIVADA,
                  com.reporteai.model.enums.StatusOcorrencia.REJEITADA
              )
            ORDER BY o.scorePrioridade DESC
            """)
    List<Ocorrencia> findTopPrioridade(@Param("cidadeId") Long cidadeId, Pageable pageable);

    // Heatmap data
    @Query(value = """
            SELECT o.latitude, o.longitude, o.score_prioridade, c.nome as categoria_nome
            FROM ocorrencias o
            JOIN categorias c ON c.id = o.categoria_id
            WHERE o.cidade_id = :cidadeId
              AND o.latitude IS NOT NULL
              AND o.longitude IS NOT NULL
              AND o.data_registro >= :desde
            """, nativeQuery = true)
    List<Object[]> findHeatmapData(
            @Param("cidadeId") Long cidadeId,
            @Param("desde") OffsetDateTime desde);

    // Ranking de categorias
    @Query(value = """
            SELECT c.nome, c.cor, COUNT(o.id) as total,
                   ROUND(AVG(o.score_prioridade), 2) as score_medio,
                   COUNT(o.id) FILTER (WHERE o.data_registro >= NOW() - INTERVAL '7 days') as ultimos_7,
                   COUNT(o.id) FILTER (WHERE o.data_registro >= NOW() - INTERVAL '30 days') as ultimos_30
            FROM ocorrencias o
            JOIN categorias c ON c.id = o.categoria_id
            WHERE o.cidade_id = :cidadeId
            GROUP BY c.id, c.nome, c.cor
            ORDER BY total DESC
            """, nativeQuery = true)
    List<Object[]> findRankingCategorias(@Param("cidadeId") Long cidadeId);

    // Média de tempo de resolução em dias
    @Query(value = """
            SELECT ROUND(AVG(EXTRACT(EPOCH FROM (data_resolucao - data_registro)) / 86400), 1)
            FROM ocorrencias
            WHERE cidade_id = :cidadeId AND data_resolucao IS NOT NULL
            """, nativeQuery = true)
    Double findTempoMedioResolucao(@Param("cidadeId") Long cidadeId);
}
