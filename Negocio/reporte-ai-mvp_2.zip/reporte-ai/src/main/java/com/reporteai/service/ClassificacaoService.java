package com.reporteai.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.reporteai.model.entity.Categoria;
import com.reporteai.model.entity.Subcategoria;
import com.reporteai.repository.CategoriaRepository;
import com.reporteai.repository.SubcategoriaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.text.Normalizer;
import java.util.*;

/**
 * Classifica ocorrências em categoria/subcategoria.
 * 
 * Estratégia dupla:
 * 1. OpenAI API (primário) - classificação via LLM
 * 2. Keyword matching (fallback) - quando API indisponível
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class ClassificacaoService {

    private final CategoriaRepository categoriaRepository;
    private final SubcategoriaRepository subcategoriaRepository;
    private final ObjectMapper objectMapper;

    @Value("${reporteai.classificacao.openai.api-key:}")
    private String openaiApiKey;

    @Value("${reporteai.classificacao.openai.model:gpt-4o-mini}")
    private String openaiModel;

    @Value("${reporteai.classificacao.fallback-keywords:true}")
    private boolean fallbackKeywords;

    private WebClient webClient;

    private WebClient getWebClient() {
        if (webClient == null) {
            webClient = WebClient.builder()
                    .baseUrl("https://api.openai.com/v1")
                    .defaultHeader("Authorization", "Bearer " + openaiApiKey)
                    .build();
        }
        return webClient;
    }

    /**
     * Resultado da classificação.
     */
    public record ClassificacaoResult(
            Long categoriaId,
            Long subcategoriaId,
            double confianca,
            boolean classificadoPorIa
    ) {}

    /**
     * Classifica a descrição de uma ocorrência.
     * Tenta OpenAI primeiro, fallback para keywords.
     */
    public ClassificacaoResult classificar(String descricao) {
        // Tenta OpenAI se configurado
        if (openaiApiKey != null && !openaiApiKey.isBlank()) {
            try {
                return classificarComOpenAI(descricao);
            } catch (Exception e) {
                log.warn("Falha na classificação via OpenAI, usando fallback: {}", e.getMessage());
            }
        }

        // Fallback: keyword matching
        if (fallbackKeywords) {
            return classificarPorKeywords(descricao);
        }

        // Sem classificação possível
        return new ClassificacaoResult(null, null, 0.0, false);
    }

    /**
     * Classificação via OpenAI API.
     */
    private ClassificacaoResult classificarComOpenAI(String descricao) {
        List<Categoria> categorias = categoriaRepository.findByAtivaTrue();
        
        StringBuilder catList = new StringBuilder();
        for (Categoria cat : categorias) {
            catList.append(String.format("- %s (id=%d): %s\n", cat.getCodigo(), cat.getId(), cat.getDescricao()));
        }

        String systemPrompt = """
                Você é um classificador de ocorrências urbanas para cidades brasileiras.
                Receba a descrição de um problema e classifique na categoria e subcategoria mais adequada.
                
                Categorias disponíveis:
                %s
                
                Responda APENAS com JSON no formato:
                {"categoria_codigo": "CODIGO", "categoria_id": N, "subcategoria_codigo": "CODIGO", "confianca": 0.95}
                
                Se não conseguir classificar com certeza, use "OUTROS".
                O campo confianca deve ser entre 0 e 1.
                """.formatted(catList.toString());

        String requestBody = """
                {
                    "model": "%s",
                    "temperature": 0.1,
                    "max_tokens": 200,
                    "messages": [
                        {"role": "system", "content": %s},
                        {"role": "user", "content": %s}
                    ]
                }
                """.formatted(
                openaiModel,
                objectMapper.valueToTree(systemPrompt).toString(),
                objectMapper.valueToTree(descricao).toString()
        );

        String response = getWebClient()
                .post()
                .uri("/chat/completions")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(requestBody)
                .retrieve()
                .bodyToMono(String.class)
                .block();

        JsonNode root = parseJson(response);
        String content = root.path("choices").path(0).path("message").path("content").asText();

        // Limpar possíveis backticks de markdown
        content = content.replaceAll("```json\\s*", "").replaceAll("```\\s*", "").trim();
        JsonNode result = parseJson(content);

        Long catId = result.path("categoria_id").asLong(0);
        String subcatCodigo = result.has("subcategoria_codigo") ? result.path("subcategoria_codigo").asText() : null;
        double confianca = result.path("confianca").asDouble(0.5);

        Long subcatId = null;
        if (subcatCodigo != null && catId > 0) {
            subcatId = subcategoriaRepository.findByCategoriaId(catId).stream()
                    .filter(s -> s.getCodigo().equals(subcatCodigo))
                    .map(Subcategoria::getId)
                    .findFirst().orElse(null);
        }

        return new ClassificacaoResult(catId > 0 ? catId : null, subcatId, confianca, true);
    }

    /**
     * Classificação por keyword matching (fallback).
     * Normaliza texto e compara com keywords das subcategorias.
     */
    private ClassificacaoResult classificarPorKeywords(String descricao) {
        String descNorm = normalizar(descricao);
        List<Subcategoria> todas = subcategoriaRepository.findAll();

        Long bestCatId = null;
        Long bestSubcatId = null;
        int bestScore = 0;

        for (Subcategoria sub : todas) {
            if (sub.getKeywords() == null) continue;
            int score = 0;
            for (String kw : sub.getKeywords()) {
                if (descNorm.contains(normalizar(kw))) {
                    score++;
                }
            }
            if (score > bestScore) {
                bestScore = score;
                bestCatId = sub.getCategoria().getId();
                bestSubcatId = sub.getId();
            }
        }

        // Confiança baseada em quantas keywords deram match
        double confianca = bestScore == 0 ? 0.0 : Math.min(0.9, 0.3 + (bestScore * 0.15));

        // Se nenhum match, classificar como OUTROS
        if (bestCatId == null) {
            bestCatId = categoriaRepository.findByCodigo("OUTROS")
                    .map(Categoria::getId).orElse(null);
            confianca = 0.1;
        }

        return new ClassificacaoResult(bestCatId, bestSubcatId, confianca, false);
    }

    private String normalizar(String texto) {
        if (texto == null) return "";
        String normalized = Normalizer.normalize(texto.toLowerCase(), Normalizer.Form.NFD);
        return normalized.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
    }

    private JsonNode parseJson(String json) {
        try {
            return objectMapper.readTree(json);
        } catch (Exception e) {
            throw new RuntimeException("Erro ao parsear JSON: " + e.getMessage(), e);
        }
    }
}
