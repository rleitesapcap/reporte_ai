package com.reporteai.repository;

import com.reporteai.model.entity.ConversaWhatsApp;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ConversaWhatsAppRepository extends JpaRepository<ConversaWhatsApp, Long> {

    Optional<ConversaWhatsApp> findTopByUsuarioIdAndExpiradaFalseOrderByUpdatedAtDesc(Long usuarioId);
}
