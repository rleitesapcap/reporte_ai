package com.reporteai.model.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;

@Entity
@Table(name = "categorias")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 50)
    private String codigo;

    @Column(nullable = false, length = 200)
    private String nome;

    private String descricao;

    @Column(length = 50)
    private String icone;

    @Column(length = 7)
    private String cor;

    @Column(name = "peso_prioridade")
    @Builder.Default
    private BigDecimal pesoPrioridade = BigDecimal.ONE;

    @Builder.Default
    private Boolean ativa = true;

    @OneToMany(mappedBy = "categoria", fetch = FetchType.LAZY)
    private List<Subcategoria> subcategorias;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
    }
}
