package com.reporteai.model.entity;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "vinculos_ocorrencias",
       uniqueConstraints = @UniqueConstraint(columnNames = {"ocorrencia_pai_id", "ocorrencia_filha_id"}))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class VinculoOcorrencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ocorrencia_pai_id", nullable = false)
    private Ocorrencia ocorrenciaPai;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ocorrencia_filha_id", nullable = false)
    private Ocorrencia ocorrenciaFilha;

    @Column(name = "tipo_vinculo", length = 50)
    @Builder.Default
    private String tipoVinculo = "DUPLICATA";

    @Column(name = "similaridade_texto")
    private BigDecimal similaridadeTexto;

    @Column(name = "distancia_metros")
    private BigDecimal distanciaMetros;

    @Column(name = "criado_por", length = 20)
    @Builder.Default
    private String criadoPor = "IA";

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
    }
}
