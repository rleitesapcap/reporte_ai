package com.reporteai.config;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * Tarefas agendadas da plataforma.
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class ScheduledTasks {

    @PersistenceContext
    private EntityManager em;

    /**
     * Expira conversas WhatsApp inativas (a cada 5 minutos).
     */
    @Scheduled(fixedRate = 300_000)
    @Transactional
    public void expirarConversas() {
        int updated = em.createNativeQuery("""
                UPDATE conversas_whatsapp
                SET expirada = TRUE, updated_at = NOW()
                WHERE expirada = FALSE
                  AND updated_at < NOW() - INTERVAL '30 minutes'
                """).executeUpdate();

        if (updated > 0) {
            log.info("Conversas expiradas: {}", updated);
        }
    }

    /**
     * Refresh das materialized views (a cada 15 minutos).
     */
    @Scheduled(fixedRate = 900_000)
    @Transactional
    public void refreshMaterializedViews() {
        try {
            em.createNativeQuery("SELECT fn_refresh_materialized_views()").getSingleResult();
            log.debug("Materialized views atualizadas");
        } catch (Exception e) {
            log.warn("Erro ao atualizar materialized views: {}", e.getMessage());
        }
    }
}
