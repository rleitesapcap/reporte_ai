package com.reporteai.model.entity;

import com.reporteai.model.enums.StatusOcorrencia;
import jakarta.persistence.*;
import lombok.*;
import java.time.OffsetDateTime;

@Entity
@Table(name = "historico_status")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class HistoricoStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ocorrencia_id", nullable = false)
    private Ocorrencia ocorrencia;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_anterior", columnDefinition = "status_ocorrencia")
    private StatusOcorrencia statusAnterior;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_novo", nullable = false, columnDefinition = "status_ocorrencia")
    private StatusOcorrencia statusNovo;

    @Column(length = 200)
    private String responsavel;

    @Column(columnDefinition = "TEXT")
    private String observacao;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
    }
}
