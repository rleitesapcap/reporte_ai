package com.reporteai.service;

import com.reporteai.model.entity.Ocorrencia;
import com.reporteai.model.entity.VinculoOcorrencia;
import com.reporteai.repository.OcorrenciaRepository;
import com.reporteai.repository.VinculoOcorrenciaRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.Normalizer;
import java.time.OffsetDateTime;
import java.util.*;

/**
 * Serviço de deduplicação de ocorrências.
 * 
 * MVP: Usa similaridade textual (Jaccard) + proximidade geográfica + janela temporal.
 * Evolução: Embeddings via sentence-transformers para similaridade semântica.
 */
@Service
@Slf4j
@RequiredArgsConstructor
public class DeduplicacaoService {

    private final OcorrenciaRepository ocorrenciaRepository;
    private final VinculoOcorrenciaRepository vinculoRepository;

    @Value("${reporteai.deduplicacao.raio-metros:200}")
    private double raioMetros;

    @Value("${reporteai.deduplicacao.similaridade-minima:0.75}")
    private double similaridadeMinima;

    @Value("${reporteai.deduplicacao.janela-dias:30}")
    private int janelaDias;

    /**
     * Resultado da verificação de duplicata.
     */
    public record DeduplicacaoResult(
            boolean isDuplicata,
            Ocorrencia ocorrenciaPai,
            double similaridade,
            double distanciaMetros
    ) {}

    /**
     * Verifica se uma nova ocorrência é duplicata de alguma existente.
     */
    public DeduplicacaoResult verificar(Ocorrencia nova) {
        // Se não tem coordenadas, não consegue verificar por geo — pula
        if (nova.getLatitude() == null || nova.getLongitude() == null) {
            log.debug("Ocorrência sem coordenadas, pulando deduplicação geográfica");
            return new DeduplicacaoResult(false, null, 0, 0);
        }

        OffsetDateTime desde = OffsetDateTime.now().minusDays(janelaDias);

        // Busca ocorrências próximas geograficamente
        List<Ocorrencia> proximas = ocorrenciaRepository.findProximas(
                nova.getCidade().getId(),
                nova.getLatitude().doubleValue(),
                nova.getLongitude().doubleValue(),
                raioMetros,
                desde
        );

        if (proximas.isEmpty()) {
            return new DeduplicacaoResult(false, null, 0, 0);
        }

        // Para cada próxima, calcula similaridade textual
        String descNova = normalizar(nova.getDescricao());
        Set<String> tokensNova = tokenizar(descNova);

        Ocorrencia melhorMatch = null;
        double melhorSimilaridade = 0;

        for (Ocorrencia existente : proximas) {
            // Ignora se for a mesma ocorrência
            if (existente.getId() != null && existente.getId().equals(nova.getId())) continue;

            String descExistente = normalizar(existente.getDescricao());
            Set<String> tokensExistente = tokenizar(descExistente);

            double sim = calcularJaccard(tokensNova, tokensExistente);

            // Bonus se mesma categoria
            if (nova.getCategoria() != null && existente.getCategoria() != null
                    && nova.getCategoria().getId().equals(existente.getCategoria().getId())) {
                sim = Math.min(1.0, sim + 0.15);
            }

            if (sim > melhorSimilaridade) {
                melhorSimilaridade = sim;
                melhorMatch = existente;
            }
        }

        if (melhorSimilaridade >= similaridadeMinima && melhorMatch != null) {
            return new DeduplicacaoResult(true, melhorMatch, melhorSimilaridade, 0);
        }

        return new DeduplicacaoResult(false, null, melhorSimilaridade, 0);
    }

    /**
     * Registra o vínculo de duplicata e incrementa reincidência no pai.
     */
    public void registrarDuplicata(Ocorrencia pai, Ocorrencia filha, double similaridade) {
        VinculoOcorrencia vinculo = VinculoOcorrencia.builder()
                .ocorrenciaPai(pai)
                .ocorrenciaFilha(filha)
                .tipoVinculo("DUPLICATA")
                .similaridadeTexto(BigDecimal.valueOf(similaridade))
                .criadoPor("IA")
                .build();
        vinculoRepository.save(vinculo);

        // Incrementa reincidência no pai
        pai.setReincidencia(pai.getReincidencia() + 1);
        filha.setClusterId(pai.getId());

        log.info("Duplicata detectada: {} -> {} (sim={:.2f})", filha.getProtocolo(), pai.getProtocolo(), similaridade);
    }

    // --- Helpers ---

    private String normalizar(String texto) {
        if (texto == null) return "";
        String normalized = Normalizer.normalize(texto.toLowerCase(), Normalizer.Form.NFD);
        return normalized.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "")
                .replaceAll("[^a-z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private Set<String> tokenizar(String texto) {
        Set<String> tokens = new HashSet<>();
        if (texto == null || texto.isBlank()) return tokens;
        for (String token : texto.split("\\s+")) {
            if (token.length() > 2) { // ignora stopwords curtas
                tokens.add(token);
            }
        }
        return tokens;
    }

    private double calcularJaccard(Set<String> a, Set<String> b) {
        if (a.isEmpty() && b.isEmpty()) return 0.0;
        Set<String> intersecao = new HashSet<>(a);
        intersecao.retainAll(b);
        Set<String> uniao = new HashSet<>(a);
        uniao.addAll(b);
        return (double) intersecao.size() / uniao.size();
    }
}
