package com.reporteai.model.dto;

import com.reporteai.model.enums.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class OcorrenciaResponse {

    private Long id;
    private String protocolo;

    // Classificação
    private String categoriaNome;
    private String categoriaCor;
    private String subcategoriaNome;
    private String descricao;

    // Localização
    private BigDecimal latitude;
    private BigDecimal longitude;
    private String bairroNome;
    private String enderecoTexto;

    // Avaliação
    private GravidadeOcorrencia gravidade;
    private BigDecimal scorePrioridade;
    private BigDecimal scoreConfianca;
    private Integer reincidencia;

    // Mídia
    private String fotoUrl;

    // Status
    private StatusOcorrencia status;
    private CanalEntrada canal;

    // Timestamps
    private OffsetDateTime dataRegistro;
    private OffsetDateTime dataResolucao;
}
