package com.reporteai.repository;

import com.reporteai.model.entity.VinculoOcorrencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface VinculoOcorrenciaRepository extends JpaRepository<VinculoOcorrencia, Long> {
    List<VinculoOcorrencia> findByOcorrenciaPaiId(Long paiId);
}
