package com.reporteai.model.enums;

public enum CanalEntrada {
    WHATSAPP_GUIADO,
    WHATSAPP_RAPIDO,
    WEB,
    API
}
