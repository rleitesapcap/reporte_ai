package com.reporteai.model.enums;

public enum GravidadeOcorrencia {
    BAIXA,
    MEDIA,
    ALTA,
    CRITICA
}
