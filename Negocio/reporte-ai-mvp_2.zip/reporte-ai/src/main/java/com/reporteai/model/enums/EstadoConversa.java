package com.reporteai.model.enums;

/**
 * Estados da máquina de estados do fluxo guiado WhatsApp.
 */
public enum EstadoConversa {
    INICIO,              // Aguardando primeira interação
    AGUARDANDO_CATEGORIA,// Perguntou a categoria
    AGUARDANDO_DESCRICAO,// Perguntou a descrição
    AGUARDANDO_LOCALIZACAO,// Perguntou a localização
    AGUARDANDO_GRAVIDADE,// Perguntou a gravidade
    AGUARDANDO_FOTO,     // Perguntou se tem foto
    CONFIRMACAO,         // Resumo para confirmar
    FINALIZADA,          // Ocorrência registrada
    CONSULTA_PROTOCOLO,  // Usuário consultando protocolo
    CANCELADA            // Usuário cancelou
}
