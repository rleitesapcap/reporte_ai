package com.reporteai.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.transaction.annotation.Transactional;

/**
 * Gera protocolos únicos no formato RPT-2026-XXXXX
 * Usa sequence do PostgreSQL para garantir unicidade.
 */
@Service
public class ProtocoloService {

    @Value("${reporteai.protocolo.prefixo:RPT}")
    private String prefixo;

    @Value("${reporteai.protocolo.ano:2026}")
    private int ano;

    @PersistenceContext
    private EntityManager em;

    @Transactional
    public String gerarProtocolo() {
        Long seq = (Long) em.createNativeQuery("SELECT nextval('seq_protocolo')").getSingleResult();
        return String.format("%s-%d-%05d", prefixo, ano, seq);
    }
}
