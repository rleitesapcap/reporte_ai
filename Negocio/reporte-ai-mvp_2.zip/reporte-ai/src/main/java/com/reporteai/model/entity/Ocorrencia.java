package com.reporteai.model.entity;

import com.reporteai.model.enums.*;
import jakarta.persistence.*;
import lombok.*;
import org.locationtech.jts.geom.Point;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

@Entity
@Table(name = "ocorrencias")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Ocorrencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 20)
    private String protocolo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cidade_id", nullable = false)
    private Cidade cidade;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    // --- Classificação ---

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "subcategoria_id")
    private Subcategoria subcategoria;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String descricao;

    @Column(name = "descricao_norm", columnDefinition = "TEXT")
    private String descricaoNorm;

    // --- Geolocalização ---

    @Column(precision = 10, scale = 7)
    private BigDecimal latitude;

    @Column(precision = 10, scale = 7)
    private BigDecimal longitude;

    @Column(columnDefinition = "geometry(Point,4326)")
    private Point geom;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "bairro_id")
    private Bairro bairro;

    @Column(name = "endereco_texto", length = 500)
    private String enderecoTexto;

    @Builder.Default
    private Boolean geocodificado = false;

    // --- Avaliação ---

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "gravidade_ocorrencia")
    @Builder.Default
    private GravidadeOcorrencia gravidade = GravidadeOcorrencia.MEDIA;

    @Builder.Default
    private Integer frequencia = 1;

    @Builder.Default
    private Integer reincidencia = 0;

    @Column(name = "score_prioridade")
    @Builder.Default
    private BigDecimal scorePrioridade = BigDecimal.ZERO;

    @Column(name = "score_confianca")
    @Builder.Default
    private BigDecimal scoreConfianca = new BigDecimal("50.0");

    @Column(name = "score_sentimento")
    @Builder.Default
    private BigDecimal scoreSentimento = BigDecimal.ZERO;

    // --- Mídia ---

    @Column(name = "foto_url", length = 500)
    private String fotoUrl;

    @Column(name = "foto_validada")
    @Builder.Default
    private Boolean fotoValidada = false;

    @Column(name = "audio_url", length = 500)
    private String audioUrl;

    // --- Metadata ---

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, columnDefinition = "canal_entrada")
    private CanalEntrada canal;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "status_ocorrencia")
    @Builder.Default
    private StatusOcorrencia status = StatusOcorrencia.RECEBIDA;

    @Column(name = "cluster_id")
    private Long clusterId;

    @Column(name = "classificado_por_ia")
    @Builder.Default
    private Boolean classificadoPorIa = false;

    @Column(name = "confianca_class_ia")
    private BigDecimal confiancaClassIa;

    // --- Timestamps ---

    @Column(name = "data_registro")
    private OffsetDateTime dataRegistro;

    @Column(name = "data_validacao")
    private OffsetDateTime dataValidacao;

    @Column(name = "data_resolucao")
    private OffsetDateTime dataResolucao;

    @Column(name = "created_at", updatable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = OffsetDateTime.now();
        updatedAt = OffsetDateTime.now();
        dataRegistro = OffsetDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = OffsetDateTime.now();
    }
}
