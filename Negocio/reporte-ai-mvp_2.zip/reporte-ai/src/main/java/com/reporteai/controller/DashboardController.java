package com.reporteai.controller;

import com.reporteai.model.dto.DashboardSummary;
import com.reporteai.model.entity.Categoria;
import com.reporteai.repository.CategoriaRepository;
import com.reporteai.service.OcorrenciaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * API para dashboard público e administrativo.
 * Base: /api/v1/dashboard
 */
@RestController
@RequestMapping("/api/v1/dashboard")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class DashboardController {

    private final OcorrenciaService ocorrenciaService;
    private final CategoriaRepository categoriaRepository;

    /**
     * Dashboard summary com métricas, ranking e heatmap.
     * GET /api/v1/dashboard?cidadeId=1
     */
    @GetMapping
    public ResponseEntity<DashboardSummary> getDashboard(
            @RequestParam(defaultValue = "1") Long cidadeId) {
        return ResponseEntity.ok(ocorrenciaService.getDashboard(cidadeId));
    }

    /**
     * Lista de categorias ativas (para formulários e filtros).
     * GET /api/v1/dashboard/categorias
     */
    @GetMapping("/categorias")
    public ResponseEntity<List<Categoria>> getCategorias() {
        return ResponseEntity.ok(categoriaRepository.findByAtivaTrue());
    }
}
