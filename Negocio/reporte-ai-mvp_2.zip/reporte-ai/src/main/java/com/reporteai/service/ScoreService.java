package com.reporteai.service;

import com.reporteai.model.entity.Ocorrencia;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Calcula o score de prioridade de uma ocorrência.
 * 
 * Fórmula: Score = (gravidade × pesoG) + (frequência × pesoF) + (densidade × pesoD)
 *                + (reincidência × pesoR) + (foto × pesoFoto) + (sentimento × pesoS)
 */
@Service
public class ScoreService {

    @Value("${reporteai.score.peso-gravidade:3.0}")
    private double pesoGravidade;

    @Value("${reporteai.score.peso-frequencia:2.0}")
    private double pesoFrequencia;

    @Value("${reporteai.score.peso-densidade:1.5}")
    private double pesoDensidade;

    @Value("${reporteai.score.peso-reincidencia:2.0}")
    private double pesoReincidencia;

    @Value("${reporteai.score.peso-foto:1.0}")
    private double pesoFoto;

    @Value("${reporteai.score.peso-sentimento:1.5}")
    private double pesoSentimento;

    /**
     * Calcula e seta o score de prioridade na ocorrência.
     */
    public BigDecimal calcular(Ocorrencia ocorrencia) {
        double gravidadeValor = switch (ocorrencia.getGravidade()) {
            case BAIXA -> 1.0;
            case MEDIA -> 2.0;
            case ALTA -> 3.0;
            case CRITICA -> 5.0;
        };

        double frequenciaValor = Math.min(ocorrencia.getFrequencia(), 10); // cap em 10
        double reincidenciaValor = Math.min(ocorrencia.getReincidencia(), 10);
        double fotoValor = (ocorrencia.getFotoUrl() != null && !ocorrencia.getFotoUrl().isBlank()) ? 1.0 : 0.0;
        double sentimentoValor = ocorrencia.getScoreSentimento() != null
                ? Math.max(0, ocorrencia.getScoreSentimento().doubleValue()) // normalizar para 0+
                : 0.0;

        // Densidade: placeholder — no MVP usa reincidência como proxy
        double densidadeValor = reincidenciaValor * 0.5;

        double score = (gravidadeValor * pesoGravidade)
                + (frequenciaValor * pesoFrequencia)
                + (densidadeValor * pesoDensidade)
                + (reincidenciaValor * pesoReincidencia)
                + (fotoValor * pesoFoto)
                + (sentimentoValor * pesoSentimento);

        BigDecimal result = BigDecimal.valueOf(score).setScale(2, RoundingMode.HALF_UP);
        ocorrencia.setScorePrioridade(result);
        return result;
    }
}
